package com.colorverse;

import java.io.IOException;

import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.GuiTextField;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.input.Keyboard;

// B tusu: yildirim / cimen / hava rengi secici (hex + renk karesi + ton cubugu)
public class GuiColors extends GuiScreen {
    private static final int[] PRESETS = {0xFFFFFF, 0xFF3B30, 0xFF9500, 0xFFE600, 0x34C759, 0x00E5FF,
            0x0A84FF, 0x7B2FFF, 0xFF2DAA, 0x5B3A1E, 0x2C2C2E, 0x000000};

    private int tab = 0;
    private float hue, sat, val;
    private GuiTextField hexField;
    private GuiButton toggle;
    private DynamicTexture svTex, hueTex;
    private ResourceLocation svLoc, hueLoc;
    private int px, py, ps, hx, hw, rx;
    private boolean dragSV, dragHue, grassChanged;

    @Override
    public void initGui() {
        Keyboard.enableRepeatEvents(true);
        buttonList.clear();
        int left = Math.max(4, width / 2 - 150);
        for (int i = 0; i < 3; i++) addButton(new GuiButton(i, left + i * 100, 6, 98, 20, ColorSettings.TAB_NAMES[i]));
        ps = Math.max(48, Math.min(110, height - 70));
        px = left;
        py = 34;
        hx = px + ps + 8;
        hw = 12;
        rx = hx + hw + 12;
        hexField = new GuiTextField(10, fontRenderer, rx, 34, 66, 16);
        hexField.setMaxStringLength(7);
        toggle = addButton(new GuiButton(20, rx, 72, 58, 20, "Acik"));
        addButton(new GuiButton(21, rx + 62, 72, 58, 20, "Sifirla"));
        addButton(new GuiButton(22, rx, 94, 120, 20, "Bitti"));

        if (svTex == null) {
            svTex = new DynamicTexture(128, 128);
            svLoc = mc.getTextureManager().getDynamicTextureLocation("cv_sv", svTex);
            hueTex = new DynamicTexture(1, 128);
            hueLoc = mc.getTextureManager().getDynamicTextureLocation("cv_hue", hueTex);
            int[] hd = hueTex.getTextureData();
            for (int y = 0; y < 128; y++) hd[y] = 0xFF000000 | ColorSettings.hsvToRgb(y / 128.0F, 1.0F, 1.0F);
            hueTex.updateDynamicTexture();
        }
        loadTab(tab);
    }

    private void loadTab(int t) {
        tab = t;
        float[] hsv = ColorSettings.rgbToHsv(ColorSettings.color[t]);
        hue = hsv[0];
        sat = hsv[1];
        val = hsv[2];
        hexField.setText(String.format("#%06X", ColorSettings.color[t]));
        toggle.displayString = ColorSettings.enabled[t] ? "Acik" : "Kapali";
        rebuildSV();
    }

    private void rebuildSV() {
        int[] d = svTex.getTextureData();
        for (int y = 0; y < 128; y++)
            for (int x = 0; x < 128; x++)
                d[y * 128 + x] = 0xFF000000 | ColorSettings.hsvToRgb(hue, x / 127.0F, 1.0F - y / 127.0F);
        svTex.updateDynamicTexture();
    }

    private void applyHsv() {
        setRgb(ColorSettings.hsvToRgb(hue, sat, val), false);
    }

    private void setRgb(int rgb, boolean updateHsv) {
        rgb &= 0xFFFFFF;
        ColorSettings.color[tab] = rgb;
        ColorSettings.enabled[tab] = true;
        toggle.displayString = "Acik";
        hexField.setText(String.format("#%06X", rgb));
        if (updateHsv) {
            float[] hsv = ColorSettings.rgbToHsv(rgb);
            hue = hsv[0];
            sat = hsv[1];
            val = hsv[2];
            rebuildSV();
        }
        if (tab == 1) grassChanged = true;
    }

    private static float clamp01(float f) { return f < 0.0F ? 0.0F : (f > 1.0F ? 1.0F : f); }

    private void pick(int mx, int my) {
        if (dragSV) {
            sat = clamp01((mx - px) / (float) (ps - 1));
            val = 1.0F - clamp01((my - py) / (float) (ps - 1));
            applyHsv();
        } else if (dragHue) {
            hue = clamp01((my - py) / (float) (ps - 1)) * 0.999F;
            rebuildSV();
            applyHsv();
        }
    }

    @Override
    protected void mouseClicked(int mx, int my, int btn) throws IOException {
        super.mouseClicked(mx, my, btn);
        hexField.mouseClicked(mx, my, btn);
        if (btn != 0) return;
        if (mx >= px && mx < px + ps && my >= py && my < py + ps) { dragSV = true; pick(mx, my); }
        else if (mx >= hx && mx < hx + hw && my >= py && my < py + ps) { dragHue = true; pick(mx, my); }
        else {
            for (int i = 0; i < PRESETS.length; i++) {
                int x = rx + (i % 6) * 20, y = 120 + (i / 6) * 20;
                if (mx >= x && mx < x + 18 && my >= y && my < y + 18) setRgb(PRESETS[i], true);
            }
        }
    }

    @Override
    protected void mouseClickMove(int mx, int my, int btn, long time) {
        if (dragSV || dragHue) pick(mx, my);
    }

    @Override
    protected void mouseReleased(int mx, int my, int state) {
        super.mouseReleased(mx, my, state);
        dragSV = false;
        dragHue = false;
    }

    @Override
    protected void keyTyped(char c, int code) throws IOException {
        if (code == Keyboard.KEY_ESCAPE) { super.keyTyped(c, code); return; }
        if (hexField.isFocused()) {
            hexField.textboxKeyTyped(c, code);
            String s = hexField.getText().replace("#", "");
            if (s.length() == 6) {
                try { setRgbKeepText(Integer.parseInt(s, 16)); } catch (NumberFormatException ignored) { }
            }
        } else if (code == ClientEvents.OPEN_COLORS.getKeyCode()) {
            mc.displayGuiScreen(null);
        }
    }

    private void setRgbKeepText(int rgb) {
        ColorSettings.color[tab] = rgb & 0xFFFFFF;
        ColorSettings.enabled[tab] = true;
        toggle.displayString = "Acik";
        float[] hsv = ColorSettings.rgbToHsv(rgb);
        hue = hsv[0];
        sat = hsv[1];
        val = hsv[2];
        rebuildSV();
        if (tab == 1) grassChanged = true;
    }

    @Override
    protected void actionPerformed(GuiButton b) throws IOException {
        if (b.id >= 0 && b.id <= 2) {
            loadTab(b.id);
        } else if (b.id == 20) {
            ColorSettings.enabled[tab] = !ColorSettings.enabled[tab];
            toggle.displayString = ColorSettings.enabled[tab] ? "Acik" : "Kapali";
            if (tab == 1) grassChanged = true;
        } else if (b.id == 21) {
            ColorSettings.color[tab] = ColorSettings.DEFAULTS[tab];
            ColorSettings.enabled[tab] = ColorSettings.DEFAULT_ENABLED[tab];
            if (tab == 1) grassChanged = true;
            loadTab(tab);
        } else if (b.id == 22) {
            mc.displayGuiScreen(null);
        }
    }

    @Override
    public void updateScreen() {
        hexField.updateCursorCounter();
    }

    @Override
    public void drawScreen(int mouseX, int mouseY, float pt) {
        drawDefaultBackground();
        GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);

        mc.getTextureManager().bindTexture(svLoc);
        drawScaledCustomSizedModalRect(px, py, 0, 0, 128, 128, ps, ps, 128, 128);
        mc.getTextureManager().bindTexture(hueLoc);
        drawScaledCustomSizedModalRect(hx, py, 0, 0, 1, 128, hw, ps, 1, 128);

        int mx = px + (int) (sat * (ps - 1)), my = py + (int) ((1.0F - val) * (ps - 1));
        drawRect(mx - 3, my - 3, mx + 4, my + 4, 0xFFFFFFFF);
        drawRect(mx - 2, my - 2, mx + 3, my + 3, 0xFF000000);
        int hy = py + (int) (hue * (ps - 1));
        drawRect(hx - 2, hy - 1, hx + hw + 2, hy + 2, 0xFFFFFFFF);

        drawRect(rx + 70, 34, rx + 120, 50, 0xFF000000 | ColorSettings.hsvToRgbSafe(hue, sat, val));
        hexField.drawTextBox();

        for (int i = 0; i < PRESETS.length; i++) {
            int x = rx + (i % 6) * 20, y = 120 + (i / 6) * 20;
            drawRect(x - 1, y - 1, x + 19, y + 19, 0xFF000000);
            drawRect(x, y, x + 18, y + 18, 0xFF000000 | PRESETS[i]);
        }
        drawCenteredString(fontRenderer, "B: kapat", width / 2, height - 12, 0xAAAAAA);
        super.drawScreen(mouseX, mouseY, pt);
    }

    @Override
    public boolean doesGuiPauseGame() { return false; }

    @Override
    public void onGuiClosed() {
        Keyboard.enableRepeatEvents(false);
        ColorSettings.save();
        if (svTex != null) svTex.deleteGlTexture();
        if (hueTex != null) hueTex.deleteGlTexture();
        if (grassChanged && mc.renderGlobal != null) mc.renderGlobal.loadRenderers(); // cimen rengini yeniden ciz
    }
}

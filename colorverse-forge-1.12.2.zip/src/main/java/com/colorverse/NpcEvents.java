package com.colorverse;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.text.TextComponentString;
import net.minecraftforge.event.ServerChatEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

@Mod.EventBusSubscriber(modid = ColorVerse.MODID)
public class NpcEvents {
    private static final String PREFIX = "\u00a7e[" + EntityNpc.NAME + "] \u00a7f";

    private static boolean has(String[] words, String... keys) {
        for (String w : words) for (String k : keys) if (w.startsWith(k)) return true;
        return false;
    }

    private static boolean hasExact(String[] words, String... keys) {
        for (String w : words) for (String k : keys) if (w.equals(k)) return true;
        return false;
    }

    // oyuncunun baktigi canli
    private static EntityLivingBase lookTarget(EntityPlayerMP p) {
        Vec3d eye = p.getPositionEyes(1.0F);
        Vec3d look = p.getLookVec();
        double range = 48.0D;
        Vec3d end = eye.add(look.x * range, look.y * range, look.z * range);
        RayTraceResult bh = p.world.rayTraceBlocks(eye, end, false, true, false);
        if (bh != null) range = bh.hitVec.distanceTo(eye);
        end = eye.add(look.x * range, look.y * range, look.z * range);

        EntityLivingBase best = null;
        double bd = range + 1.0D;
        AxisAlignedBB box = p.getEntityBoundingBox().expand(look.x * range, look.y * range, look.z * range).grow(1.0D);
        for (Entity e : p.world.getEntitiesWithinAABBExcludingEntity(p, box)) {
            if (!(e instanceof EntityLivingBase) || e instanceof EntityNpc || !e.canBeCollidedWith()) continue;
            AxisAlignedBB bb = e.getEntityBoundingBox().grow(e.getCollisionBorderSize() + 0.3D);
            RayTraceResult r = bb.calculateIntercept(eye, end);
            if (r != null) {
                double d = eye.distanceTo(r.hitVec);
                if (d < bd) { bd = d; best = (EntityLivingBase) e; }
            }
        }
        return best;
    }

    private static final Pattern NUM = Pattern.compile("-?\\d+");

    private static NpcTask parse(String seg, EntityPlayerMP p, EntityLivingBase look) {
        String[] w = seg.toLowerCase(new Locale("tr", "TR")).split("[^\\p{L}\\d-]+");
        String lower = seg.toLowerCase(new Locale("tr", "TR"));

        // sayilar: koordinat (3 sayi) ya da adet (1 sayi)
        List<Integer> nums = new ArrayList<Integer>();
        Matcher m = NUM.matcher(lower);
        while (m.find()) { try { nums.add(Integer.parseInt(m.group())); } catch (NumberFormatException ex) { } }
        int goal = (nums.size() == 1) ? Math.max(0, Math.min(nums.get(0), 2000)) : 0;

        // sohbet / durum
        if (has(w, "nas\u0131ls\u0131n", "nasilsin", "durum", "ne yap", "neyap", "rapor", "envanter", "can\u0131n", "canin")
                || lower.contains("ne yap")) {
            NpcTask t = new NpcTask(NpcTask.Kind.MODE);
            t.mode = null;
            t.reply = "@status";
            return t;
        }
        if (has(w, "selam", "merhaba", "naber")) { NpcTask t = new NpcTask(NpcTask.Kind.MODE); t.mode = null; t.reply = "Selam! Ne yapmami istersin?"; return t; }

        // koordinata git: "git 100 64 200"
        if (nums.size() >= 3 && has(w, "git", "gel", "koordinat", "ko\u015f", "kos")) {
            NpcTask t = new NpcTask(NpcTask.Kind.GOTO);
            t.pos = new BlockPos(nums.get(0), nums.get(1), nums.get(2));
            t.reply = "Koordinatlara gidiyorum: " + nums.get(0) + " " + nums.get(1) + " " + nums.get(2);
            return t;
        }
        // oyuncuya git / oyuncuyu oldur: mesajda online oyuncu adi gecerse
        for (String n : p.getServer().getOnlinePlayerNames()) {
            if (n.equalsIgnoreCase(p.getName()) || !lower.contains(n.toLowerCase(Locale.ROOT))) continue;
            EntityPlayerMP o = p.getServer().getPlayerList().getPlayerByUsername(n);
            if (o == null) continue;
            if (has(w, "\u00f6ld\u00fcr", "oldur", "sald\u0131r", "saldir", "vur")) {
                NpcTask t = new NpcTask(NpcTask.Kind.KILL);
                t.target = o;
                t.reply = n + " oyuncusuna saldiriyorum!";
                return t;
            }
            NpcTask t = new NpcTask(NpcTask.Kind.GOTO);
            t.pos = o.getPosition();
            t.reply = n + " yanina gidiyorum.";
            return t;
        }

        // buyu adini soyleyince tam o buyuyu at: "meteor yagmuru at", "kara delik"
        Spell sp = Spell.findIn(seg);
        if (sp != null) {
            NpcTask t = new NpcTask(NpcTask.Kind.SPELL);
            t.spell = sp;
            t.reply = sp.title + " buyusunu kullaniyorum!";
            return t;
        }

        NpcTask t;
        if (has(w, "ate\u015f", "ates", "fire")) t = NpcTask.mode(EntityNpc.Mode.FIRE, "Ates topu atiyorum!");
        else if (has(w, "y\u0131ld\u0131r", "yildir", "\u015fim\u015fek", "simsek")) t = NpcTask.mode(EntityNpc.Mode.THUNDER, "Yildirim yagdiriyorum!");
        else if (has(w, "buz")) { t = new NpcTask(NpcTask.Kind.ELEMENT); t.element = Element.ICE; t.reply = "Buz buyusu atiyorum!"; }
        else if (has(w, "elektrik")) { t = new NpcTask(NpcTask.Kind.ELEMENT); t.element = Element.ELECTRIC; t.reply = "Elektrik buyusu atiyorum!"; }
        else if (hasExact(w, "su")) { t = new NpcTask(NpcTask.Kind.ELEMENT); t.element = Element.WATER; t.reply = "Su buyusu atiyorum!"; }
        else if (has(w, "toprak", "deprem")) { t = new NpcTask(NpcTask.Kind.ELEMENT); t.element = Element.EARTH; t.reply = "Toprak buyusu atiyorum!"; }
        else if (has(w, "karanl\u0131k", "karanlik")) { t = new NpcTask(NpcTask.Kind.ELEMENT); t.element = Element.DARK; t.reply = "Karanlik buyusu atiyorum!"; }
        else if (has(w, "oyuncu", "pvp")) t = NpcTask.mode(EntityNpc.Mode.PVP, "Diger oyunculari avlayacagim (seni degil)!");
        else if (has(w, "\u00f6ld\u00fcr", "oldur")) {
            if (look == null) return null;
            t = new NpcTask(NpcTask.Kind.KILL);
            t.target = look;
            t.reply = look.getName() + " hedefini olduruyorum!";
        }
        else if (hasExact(w, "ev", "bina", "evi") || lower.contains("ev yap") || lower.contains("ev in")) { t = new NpcTask(NpcTask.Kind.BUILD); t.reply = "Ev yapiyorum, biraz bekle..."; }
        else if (has(w, "gel", "takip", "yan\u0131ma", "yanima", "bana")) t = NpcTask.mode(EntityNpc.Mode.FOLLOW, "Geliyorum!");
        else if (has(w, "dur", "bekle")) t = NpcTask.mode(EntityNpc.Mode.STAY, "Tamam, burada bekliyorum.");
        else if (has(w, "sald\u0131r", "saldir", "vur", "sava\u015f", "savas", "koru")) t = NpcTask.mode(EntityNpc.Mode.FIGHT, "Canavarlara saldiriyorum!");
        else if (has(w, "odun", "a\u011fa\u00e7", "agac", "kes")) t = NpcTask.mode(EntityNpc.Mode.WOOD, goal > 0 ? goal + " odun topluyorum." : "Odun topluyorum.");
        else if (has(w, "ta\u015f", "tas")) t = NpcTask.mode(EntityNpc.Mode.STONE, goal > 0 ? goal + " tas kaziyorum." : "Tas kaziyorum.");
        else if (has(w, "maden", "kaz", "elmas", "k\u00f6m\u00fcr", "komur")) t = NpcTask.mode(EntityNpc.Mode.ORE, goal > 0 ? goal + " maden kaziyorum." : "Maden ariyorum (komur, demir, altin, elmas...)!");
        else if (has(w, "topla", "e\u015fya", "esya")) t = NpcTask.mode(EntityNpc.Mode.COLLECT, "Yerdeki esyalari topluyorum.");
        else if (has(w, "ver", "getir")) { t = new NpcTask(NpcTask.Kind.GIVE); t.reply = "@give"; }
        else return null;
        t.goal = goal;
        return t;
    }

    @SubscribeEvent
    public static void onChat(ServerChatEvent event) {
        EntityPlayerMP p = event.getPlayer();
        String msg = event.getMessage().trim();

        boolean named = false;
        if (msg.toLowerCase(Locale.ROOT).startsWith(EntityNpc.NAME)) {
            named = true;
            msg = msg.substring(EntityNpc.NAME.length()).replaceFirst("^[\\s,:;!.]+", "");
            if (msg.isEmpty()) msg = "gel";
        }

        List<EntityNpc> npcs = new ArrayList<EntityNpc>();
        if (named) {
            for (Entity e : p.world.loadedEntityList) if (e instanceof EntityNpc) npcs.add((EntityNpc) e);
        } else {
            npcs.addAll(p.world.getEntitiesWithinAABB(EntityNpc.class, p.getEntityBoundingBox().grow(48.0D)));
        }
        if (npcs.isEmpty()) {
            if (named) p.sendMessage(new TextComponentString(PREFIX + "Bu bolgede degilim, yuklu alanda olmam lazim."));
            return;
        }

        // "odun kes sonra ev yap sonra gel" -> sirayla yapilacak gorevler
        EntityLivingBase look = lookTarget(p);
        String[] parts = msg.split("(?i)\\s*(,|;|\\bsonra\\b|\\bard\u0131ndan\\b|\\bardindan\\b|\\bve sonra\\b|\\bonu bitirince\\b|\\bthen\\b)\\s*");
        List<NpcTask> tasks = new ArrayList<NpcTask>();
        for (String part : parts) {
            if (part.trim().isEmpty()) continue;
            NpcTask t = parse(part, p, look);
            if (t != null) tasks.add(t);
        }
        if (tasks.isEmpty()) {
            if (named) p.sendMessage(new TextComponentString(PREFIX + "Tam anlayamadim ama dene: gel, dur, saldir, 20 odun kes, 10 maden kaz, git 100 64 200, "
                    + "meteor, kara delik (28+10 buyunun hepsini adiyla soyleyebilirsin), ev yap, oldur, durum. "
                    + "Birlestir: \"odun kes sonra ev yap sonra gel\"."));
            return;
        }

        for (EntityNpc npc : npcs) {
            NpcTask first = tasks.get(0);
            if (first.reply != null && first.reply.equals("@status")) {
                p.sendMessage(new TextComponentString(PREFIX + npc.status()));
                continue;
            }
            if (first.reply != null && first.reply.equals("@give")) {
                int n = npc.giveItemsTo(p);
                p.sendMessage(new TextComponentString(PREFIX + (n > 0 ? "Sana " + n + " esya verdim." : "Envanterim bos.")));
                continue;
            }
            if (first.mode == null && first.kind == NpcTask.Kind.MODE) { // sadece sohbet
                p.sendMessage(new TextComponentString(PREFIX + first.reply));
                continue;
            }
            npc.queueTasks(tasks.subList(1, tasks.size()));
            first.start(npc, p);
            String text = first.reply;
            if (tasks.size() > 1) text += " (sonra " + (tasks.size() - 1) + " gorev daha yapacagim)";
            p.sendMessage(new TextComponentString(PREFIX + text));
        }
    }
}

package com.colorverse;

public enum Element {
    FIRE("fire", 30),
    ICE("ice", 25),
    ELECTRIC("electric", 20),
    LIGHTNING("lightning", 60),
    WATER("water", 30),
    EARTH("earth", 40),
    DARK("dark", 35);

    public final String id;
    public final int cooldown;

    Element(String id, int cooldown) {
        this.id = id;
        this.cooldown = cooldown;
    }
}

package com.colorverse;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.block.model.ModelResourceLocation;
import net.minecraft.entity.effect.EntityLightningBolt;
import net.minecraft.item.Item;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.World;
import net.minecraftforge.client.event.EntityViewRenderEvent;
import net.minecraftforge.client.event.ModelRegistryEvent;
import net.minecraftforge.client.model.ModelLoader;
import net.minecraftforge.event.terraingen.BiomeEvent;
import net.minecraftforge.fml.client.registry.ClientRegistry;
import net.minecraftforge.fml.client.registry.RenderingRegistry;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.InputEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import net.minecraftforge.fml.relauncher.Side;
import org.lwjgl.input.Keyboard;

@Mod.EventBusSubscriber(value = Side.CLIENT, modid = ColorVerse.MODID)
public class ClientEvents {
    public static final KeyBinding OPEN_COLORS = new KeyBinding("key.colorverse.colors", Keyboard.KEY_B, "key.categories.colorverse");

    @SubscribeEvent
    public static void models(ModelRegistryEvent e) {
        ColorSettings.load();
        ClientRegistry.registerKeyBinding(OPEN_COLORS);
        RenderingRegistry.registerEntityRenderingHandler(EntityNpc.class, RenderNpc::new);
        RenderingRegistry.registerEntityRenderingHandler(EntityLightningBolt.class, RenderColoredBolt::new);
        for (ColorPortalBlock b : Registry.PORTALS) {
            ModelLoader.setCustomModelResourceLocation(Item.getItemFromBlock(b), 0,
                    new ModelResourceLocation(b.getRegistryName(), "inventory"));
        }
        for (ItemWand wand : Registry.WANDS) {
            ModelLoader.setCustomModelResourceLocation(wand, 0, new ModelResourceLocation(wand.getRegistryName(), "inventory"));
        }
    }

    @SubscribeEvent
    public static void onKey(InputEvent.KeyInputEvent e) {
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.player != null && mc.currentScreen == null && OPEN_COLORS.isPressed()) {
            mc.displayGuiScreen(new GuiColors());
        }
    }

    // cimen rengi
    @SubscribeEvent
    public static void grass(BiomeEvent.GetGrassColor e) {
        ColorSettings.load();
        if (ColorSettings.enabled[1]) e.setNewColor(ColorSettings.color[1]);
    }

    // hava (gokyuzu) rengi: ozel gokyuzu cizici + sis rengi
    @SubscribeEvent
    public static void tick(TickEvent.ClientTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;
        World w = Minecraft.getMinecraft().world;
        if (w == null) return;
        if (ColorSettings.enabled[2]) {
            if (w.provider.getSkyRenderer() != ColorSkyRenderer.INSTANCE) w.provider.setSkyRenderer(ColorSkyRenderer.INSTANCE);
        } else if (w.provider.getSkyRenderer() == ColorSkyRenderer.INSTANCE) {
            w.provider.setSkyRenderer(null);
        }
    }

    @SubscribeEvent
    public static void fog(EntityViewRenderEvent.FogColors e) {
        if (!ColorSettings.enabled[2]) return;
        World w = Minecraft.getMinecraft().world;
        if (w == null) return;
        float br = 0.25F + 0.75F * MathHelper.clamp(w.getSunBrightness(1.0F), 0.0F, 1.0F);
        int c = ColorSettings.color[2];
        e.setRed(((c >> 16) & 255) / 255.0F * br);
        e.setGreen(((c >> 8) & 255) / 255.0F * br);
        e.setBlue((c & 255) / 255.0F * br);
    }
}

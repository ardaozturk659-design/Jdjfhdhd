package com.colorverse;

import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.Entity;
import net.minecraft.item.EnumDyeColor;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.world.WorldServer;
import net.minecraftforge.common.DimensionManager;

public class ColorPortalBlock extends Block {
    public final int index;

    public ColorPortalBlock(int index) {
        super(Material.ROCK);
        this.index = index;
        String n = "portal_" + EnumDyeColor.byMetadata(index).getName();
        setRegistryName(ColorVerse.MODID, n);
        setTranslationKey(ColorVerse.MODID + "." + n);
        setCreativeTab(CreativeTabs.BUILDING_BLOCKS);
        setHardness(2.0F);
        setResistance(10.0F);
        setLightLevel(0.8F);
    }

    // Bloğun üstüne basınca ışınlanır
    @Override
    public void onEntityWalk(World world, BlockPos pos, Entity entity) {
        if (world.isRemote || entity.isRiding() || entity.isBeingRidden() || entity.timeUntilPortal > 0) return;

        int here = world.provider.getDimension();
        int mine = ColorVerse.BASE_ID + index;
        int target = (here == mine) ? 0 : mine; // evrendeysen overworld'e dön

        if (DimensionManager.getWorld(target) == null) DimensionManager.initDimension(target);
        WorldServer tw = DimensionManager.getWorld(target);
        if (tw == null) return;

        entity.timeUntilPortal = 100;
        entity.changeDimension(target, new ColorTeleporter(tw));
    }
}

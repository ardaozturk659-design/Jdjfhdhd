package com.colorverse;

import net.minecraft.entity.ai.EntityAIBase;
import net.minecraft.entity.player.EntityPlayer;

public class EntityAIFollowCommander extends EntityAIBase {
    private final EntityNpc npc;
    private EntityPlayer player;
    private int timer;

    public EntityAIFollowCommander(EntityNpc npc) {
        this.npc = npc;
        setMutexBits(3);
    }

    private boolean follows() {
        EntityNpc.Mode m = npc.getMode();
        return m == EntityNpc.Mode.FOLLOW || m == EntityNpc.Mode.FIGHT || m == EntityNpc.Mode.THUNDER || m == EntityNpc.Mode.FIRE || m == EntityNpc.Mode.PVP || m == EntityNpc.Mode.SPELL;
    }

    @Override
    public boolean shouldExecute() {
        if (!follows()) return false;
        player = npc.getCommander();
        return player != null && !player.isSpectator() && npc.getDistanceSq(player) > 16.0D;
    }

    @Override
    public boolean shouldContinueExecuting() {
        return follows() && player != null && player.isEntityAlive() && npc.getDistanceSq(player) > 6.0D;
    }

    @Override
    public void startExecuting() { timer = 0; }

    @Override
    public void resetTask() {
        player = null;
        npc.getNavigator().clearPath();
    }

    @Override
    public void updateTask() {
        if (--timer <= 0) {
            timer = 10;
            if (npc.getDistanceSq(player) > 576.0D) npc.teleportNear(player);
            else npc.getNavigator().tryMoveToEntityLiving(player, 1.2D);
        }
    }
}

package com.colorverse;

import java.util.LinkedList;
import java.util.UUID;

import net.minecraft.entity.EntityCreature;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.EntityAIAttackMelee;
import net.minecraft.entity.ai.EntityAILookIdle;
import net.minecraft.entity.ai.EntityAINearestAttackableTarget;
import net.minecraft.entity.ai.EntityAISwimming;
import net.minecraft.entity.ai.EntityAIWander;
import net.minecraft.entity.ai.EntityAIWatchClosest;
import net.minecraft.entity.effect.EntityLightningBolt;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.projectile.EntitySmallFireball;
import net.minecraft.entity.monster.EntityMob;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.init.SoundEvents;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.inventory.InventoryBasic;
import net.minecraft.inventory.InventoryHelper;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.pathfinding.PathNavigateGround;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.NonNullList;
import net.minecraft.util.SoundEvent;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.block.state.IBlockState;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.World;

public class EntityNpc extends EntityCreature {
    public static final String NAME = "darklord5456";
    public enum Mode { IDLE, FOLLOW, STAY, FIGHT, WOOD, STONE, COLLECT, THUNDER, FIRE, ORE, PVP, BUILD, SPELL, GOTO }

    private Mode mode = Mode.IDLE;
    private UUID commander;
    private int noPickup;
    private final LinkedList<HouseBuilder.Step> buildQueue = new LinkedList<HouseBuilder.Step>();
    private BlockPos buildCenter;
    private Element element = Element.ICE;
    private Spell forcedSpell;
    private BlockPos gotoPos;
    private int harvested, taskTicks;
    private NpcTask current;
    private final LinkedList<NpcTask> queue = new LinkedList<NpcTask>();
    public final InventoryBasic inventory = new InventoryBasic("Bot", false, 27);

    public EntityNpc(World world) {
        super(world);
        setSize(0.6F, 1.8F);
        enablePersistence();
        setCustomNameTag(NAME);
        setAlwaysRenderNameTag(true);
        setDropChance(EntityEquipmentSlot.MAINHAND, 0.0F);
        ((PathNavigateGround) getNavigator()).setCanSwim(true);
        updateHeldItem();
    }

    @Override
    protected void initEntityAI() {
        tasks.addTask(0, new EntityAISwimming(this));
        tasks.addTask(1, new EntityAIAttackMelee(this, 1.2D, true));
        tasks.addTask(2, new EntityAIWork(this));
        tasks.addTask(3, new EntityAIFollowCommander(this));
        tasks.addTask(5, new EntityAIWander(this, 0.8D) {
            @Override
            public boolean shouldExecute() {
                return EntityNpc.this.getMode() == Mode.IDLE && super.shouldExecute();
            }
        });
        tasks.addTask(6, new EntityAIWatchClosest(this, EntityPlayer.class, 8.0F));
        tasks.addTask(7, new EntityAILookIdle(this));
        targetTasks.addTask(2, new EntityAINearestAttackableTarget<EntityPlayer>(this, EntityPlayer.class, 10, true, false,
                new com.google.common.base.Predicate<EntityPlayer>() {
                    @Override
                    public boolean apply(EntityPlayer e) {
                        return EntityNpc.this.mode == Mode.PVP && !e.isCreative() && !e.isSpectator()
                                && !e.getUniqueID().equals(EntityNpc.this.commander);
                    }
                }));
        targetTasks.addTask(1, new EntityAINearestAttackableTarget<EntityMob>(this, EntityMob.class, 10, true, false,
                new com.google.common.base.Predicate<EntityMob>() {
                    @Override
                    public boolean apply(EntityMob e) {
                        Mode m = EntityNpc.this.getMode();
                        return m == Mode.FIGHT || ((m == Mode.FOLLOW || m == Mode.IDLE || m == Mode.GOTO)
                                && e.getDistanceSq(EntityNpc.this) < 64.0D);
                    }
                }));
    }

    @Override
    protected void applyEntityAttributes() {
        super.applyEntityAttributes();
        getEntityAttribute(SharedMonsterAttributes.MAX_HEALTH).setBaseValue(40.0D); // 20 kalp
        getEntityAttribute(SharedMonsterAttributes.MOVEMENT_SPEED).setBaseValue(0.3D);
        getEntityAttribute(SharedMonsterAttributes.FOLLOW_RANGE).setBaseValue(32.0D);
        getAttributeMap().registerAttribute(SharedMonsterAttributes.ATTACK_DAMAGE).setBaseValue(7.0D);
    }

    public Mode getMode() { return mode; }

    public void setMode(Mode m, EntityPlayer by) {
        this.mode = m;
        harvested = 0;
        if (m != Mode.SPELL) forcedSpell = null;
        if (m != Mode.BUILD) buildQueue.clear();
        if (by != null) this.commander = by.getUniqueID();
        setAttackTarget(null);
        getNavigator().clearPath();
        updateHeldItem();
    }

    public EntityPlayer getCommander() {
        return commander == null ? null : world.getPlayerEntityByUUID(commander);
    }

    public void teleportNear(EntityPlayer p) {
        setLocationAndAngles(p.posX + 1.0D, p.posY, p.posZ + 1.0D, rotationYaw, rotationPitch);
        getNavigator().clearPath();
    }

    private void updateHeldItem() {
        ItemStack s;
        if (mode == Mode.WOOD) s = new ItemStack(Items.IRON_AXE);
        else if (mode == Mode.STONE || mode == Mode.ORE) s = new ItemStack(Items.IRON_PICKAXE);
        else if (mode == Mode.THUNDER) s = new ItemStack(Items.BLAZE_ROD);
        else if (mode == Mode.FIRE) s = new ItemStack(Items.FIRE_CHARGE);
        else if (mode == Mode.BUILD) s = new ItemStack(Blocks.PLANKS);
        else if (mode == Mode.SPELL) s = new ItemStack(Registry.WANDS[element.ordinal()]);
        else s = new ItemStack(Items.IRON_SWORD);
        setItemStackToSlot(EntityEquipmentSlot.MAINHAND, s);
    }


    // ---- gorev kuyrugu ("odun kes sonra ev yap sonra gel") ----
    public void beginTask(NpcTask t) { current = t; taskTicks = 0; harvested = 0; }

    public void queueTasks(java.util.List<NpcTask> l) { queue.clear(); queue.addAll(l); }

    public int queued() { return queue.size(); }

    public void startGoto(BlockPos p, EntityPlayer by) {
        setMode(Mode.GOTO, by);
        gotoPos = p;
        getNavigator().tryMoveToXYZ(p.getX() + 0.5D, p.getY(), p.getZ() + 0.5D, 1.3D);
    }

    // belirli bir buyuyu ad vererek kullan
    public void setForcedSpell(Spell sp, EntityPlayer by) {
        element = sp.element;
        if (!sp.attack) { // koruma/iyilesme buyusu: hemen kendine at
            setMode(Mode.FOLLOW, by);
            SpellCasting.cast(sp, this, getLookVec());
            return;
        }
        setMode(Mode.SPELL, by);
        forcedSpell = sp;
        updateHeldItem();
    }

    private boolean taskDone() {
        if (current == null) return true;
        switch (current.kind) {
            case GIVE: return true;
            case BUILD: return mode != Mode.BUILD;
            case KILL: return getAttackTarget() == null;
            case GOTO: return mode != Mode.GOTO;
            default: break;
        }
        if (current.goal > 0 && harvested >= current.goal) return true;
        int lim = current.limit > 0 ? current.limit : 600;
        return taskTicks > lim;
    }

    public String status() {
        String m;
        switch (mode) {
            case FOLLOW: m = "seni takip ediyorum"; break;
            case STAY: m = "bekliyorum"; break;
            case FIGHT: m = "canavarlarla savasiyorum"; break;
            case WOOD: m = "odun topluyorum (" + harvested + ")"; break;
            case STONE: m = "tas kaziyorum (" + harvested + ")"; break;
            case ORE: m = "maden kaziyorum (" + harvested + ")"; break;
            case COLLECT: m = "esya topluyorum"; break;
            case THUNDER: m = "yildirim yagdiriyorum"; break;
            case FIRE: m = "ates topu atiyorum"; break;
            case PVP: m = "oyuncu avliyorum"; break;
            case BUILD: m = "ev yapiyorum"; break;
            case GOTO: m = "bir yere gidiyorum"; break;
            case SPELL: m = (forcedSpell != null ? forcedSpell.title : element.id) + " buyusu atiyorum"; break;
            default: m = "bos duruyorum"; break;
        }
        int items = 0;
        for (int i = 0; i < inventory.getSizeInventory(); i++) items += inventory.getStackInSlot(i).getCount();
        return "Su an " + m + ". Can: " + (int) getHealth() + "/" + (int) getMaxHealth() + ", envanter: " + items + " esya"
                + (queue.isEmpty() ? "." : ", siradaki gorev: " + queue.size() + ".");
    }

    public UUID getCommanderId() { return commander; }

    // bakilan canliyi olduru
    public void killTarget(EntityLivingBase t, EntityPlayer by) {
        setMode(Mode.FOLLOW, by);
        setAttackTarget(t);
    }

    public void setSpell(Element e, EntityPlayer by) {
        element = e;
        setMode(Mode.SPELL, by);
    }

    // 9x9 bir ev yap (komutanin yaninda)
    public void startBuild(EntityPlayer p) {
        BlockPos o = new BlockPos(MathHelper.floor(p.posX) + 3, MathHelper.floor(p.posY) - 1, MathHelper.floor(p.posZ) - 4);
        HouseBuilder.clearArea(world, o);
        setMode(Mode.BUILD, p);
        buildQueue.addAll(HouseBuilder.plan(o));
        buildCenter = o.add(4, 1, 4);
    }

    // ---- envanter ----
    public void addToInventory(ItemStack stack) {
        ItemStack rest = inventory.addItem(stack);
        if (!rest.isEmpty()) entityDropItem(rest, 0.0F);
    }

    public int giveItemsTo(EntityPlayer p) {
        int n = 0;
        for (int i = 0; i < inventory.getSizeInventory(); i++) {
            ItemStack s = inventory.getStackInSlot(i);
            if (!s.isEmpty()) {
                n += s.getCount();
                world.spawnEntity(new EntityItem(world, p.posX, p.posY + 0.5D, p.posZ, s.copy()));
                inventory.setInventorySlotContents(i, ItemStack.EMPTY);
            }
        }
        if (n > 0) noPickup = 80;
        return n;
    }

    // blok kir ve esyalari envantere al
    public void harvest(BlockPos pos) {
        IBlockState s = world.getBlockState(pos);
        NonNullList<ItemStack> drops = NonNullList.create();
        s.getBlock().getDrops(drops, world, pos, s, 0);
        world.destroyBlock(pos, false);
        harvested++;
        for (ItemStack d : drops) addToInventory(d);
    }

    @Override
    public void onLivingUpdate() {
        super.onLivingUpdate();
        if (world.isRemote) return;
        if (noPickup > 0) noPickup--;
        if (!isEntityAlive()) return;
        if (ticksExisted % 40 == 0) heal(1.0F);
        taskTicks++;
        if (current != null && !queue.isEmpty() && taskDone()) {
            NpcTask next = queue.poll();
            EntityPlayer cmd = getCommander();
            if (cmd != null && next.reply != null && !next.reply.startsWith("@")) cmd.sendMessage(new TextComponentString("\u00a7e[" + NAME + "] \u00a7f" + next.reply));
            next.start(this, cmd);
        }
        if (mode == Mode.GOTO && gotoPos != null) {
            if (getDistanceSq(gotoPos) < 9.0D || taskTicks > 1200) { gotoPos = null; setMode(Mode.FOLLOW, null); }
            else if (ticksExisted % 20 == 0) getNavigator().tryMoveToXYZ(gotoPos.getX() + 0.5D, gotoPos.getY(), gotoPos.getZ() + 0.5D, 1.3D);
        }
        if (mode == Mode.SPELL && ticksExisted % (forcedSpell != null ? forcedSpell.cooldown : element.cooldown) == 0) {
            EntityPlayer c = getCommander();
            EntityMob best = null;
            double bd = Double.MAX_VALUE;
            for (EntityMob m : world.getEntitiesWithinAABB(EntityMob.class, getEntityBoundingBox().grow(24.0D))) {
                if (!m.isEntityAlive()) continue;
                if (c != null && m.getDistanceSq(c) < 9.0D) continue;
                double d = getDistanceSq(m);
                if (d < bd) { bd = d; best = m; }
            }
            if (best != null) {
                swingArm(EnumHand.MAIN_HAND);
                net.minecraft.util.math.Vec3d eye = getPositionEyes(1.0F);
                net.minecraft.util.math.Vec3d tgt = new net.minecraft.util.math.Vec3d(best.posX, best.posY + best.height / 2.0D, best.posZ);
                SpellCasting.cast(forcedSpell != null ? forcedSpell : Spell.randomAttack(element, rand), this, tgt.subtract(eye));
            }
        }
        if (mode == Mode.BUILD) {
            if (buildCenter != null && ticksExisted % 20 == 0 && getDistanceSq(buildCenter) > 100.0D) {
                getNavigator().tryMoveToXYZ(buildCenter.getX(), buildCenter.getY(), buildCenter.getZ(), 1.2D);
            }
            if (ticksExisted % 3 == 0) {
                for (int i = 0; i < 3; i++) {
                    HouseBuilder.Step st = buildQueue.poll();
                    if (st == null) {
                        EntityPlayer c = getCommander();
                        if (c != null) c.sendMessage(new TextComponentString("\u00a7e[" + NAME + "] \u00a7fEv bitti!"));
                        setMode(Mode.FOLLOW, null);
                        break;
                    }
                    st.place(world);
                }
                swingArm(EnumHand.MAIN_HAND);
            }
        }
        if (mode == Mode.THUNDER && ticksExisted % 30 == 0) {
            EntityPlayer c = getCommander();
            EntityMob best = null;
            double bd = Double.MAX_VALUE;
            for (EntityMob m : world.getEntitiesWithinAABB(EntityMob.class, getEntityBoundingBox().grow(24.0D))) {
                if (!m.isEntityAlive()) continue;
                if (c != null && m.getDistanceSq(c) < 16.0D) continue;
                double d = getDistanceSq(m);
                if (d < 9.0D) continue;
                if (d < bd) { bd = d; best = m; }
            }
            if (best != null) {
                swingArm(EnumHand.MAIN_HAND);
                world.addWeatherEffect(new EntityLightningBolt(world, best.posX, best.posY, best.posZ, false));
            }
        }
        EntityLivingBase t = getAttackTarget();
        if (t != null && (t.isDead || getDistanceSq(t) > 900.0D)) setAttackTarget(null);
        if (mode == Mode.FIRE && ticksExisted % 30 == 0) {
            EntityPlayer c = getCommander();
            EntityMob best = null;
            double bd = Double.MAX_VALUE;
            for (EntityMob m : world.getEntitiesWithinAABB(EntityMob.class, getEntityBoundingBox().grow(24.0D))) {
                if (!m.isEntityAlive()) continue;
                if (c != null && m.getDistanceSq(c) < 9.0D) continue;
                double d = getDistanceSq(m);
                if (d < 4.0D) continue;
                if (d < bd) { bd = d; best = m; }
            }
            if (best != null) {
                double dx = best.posX - posX;
                double dy = best.getEntityBoundingBox().minY + best.height / 2.0D - (posY + 1.5D);
                double dz = best.posZ - posZ;
                double len = Math.sqrt(dx * dx + dy * dy + dz * dz);
                if (len > 0.001D) {
                    double ux = dx / len, uy = dy / len, uz = dz / len;
                    swingArm(EnumHand.MAIN_HAND);
                    EntitySmallFireball fb = new EntitySmallFireball(world, this, ux * 10.0D, uy * 10.0D, uz * 10.0D);
                    fb.setPosition(posX + ux * 1.2D, posY + 1.4D + uy * 1.2D, posZ + uz * 1.2D);
                    world.spawnEntity(fb);
                }
            }
        }
        if (noPickup == 0 && ticksExisted % 5 == 0) {
            for (EntityItem it : world.getEntitiesWithinAABB(EntityItem.class, getEntityBoundingBox().grow(1.2D, 0.5D, 1.2D))) {
                if (it.isDead || it.getItem().isEmpty()) continue;
                ItemStack rest = inventory.addItem(it.getItem().copy());
                if (rest.isEmpty()) it.setDead();
                else it.setItem(rest);
            }
        }
    }

    @Override
    public boolean attackEntityAsMob(net.minecraft.entity.Entity target) {
        float dmg = (float) getEntityAttribute(SharedMonsterAttributes.ATTACK_DAMAGE).getAttributeValue();
        boolean hit = target.attackEntityFrom(DamageSource.causeMobDamage(this), dmg);
        if (hit) swingArm(EnumHand.MAIN_HAND);
        return hit;
    }

    @Override
    public boolean attackEntityFrom(DamageSource source, float amount) {
        boolean r = super.attackEntityFrom(source, amount);
        if (r && !world.isRemote && source.getTrueSource() instanceof EntityLiving
                && !(source.getTrueSource() instanceof EntityPlayer)) {
            setAttackTarget((EntityLivingBase) source.getTrueSource());
        }
        return r;
    }

    @Override
    public void onDeath(DamageSource cause) {
        if (!world.isRemote) InventoryHelper.dropInventoryItems(world, this, inventory);
        super.onDeath(cause);
    }

    @Override
    public boolean processInteract(EntityPlayer player, EnumHand hand) {
        if (hand != EnumHand.MAIN_HAND) return false;
        if (!world.isRemote) {
            commander = player.getUniqueID();
            int given = giveItemsTo(player);
            String msg = given > 0 ? "Sana " + given + " esya verdim."
                    : "Merhaba! Ornek: " + NAME + " gel | dur | saldir | odun | tas | topla | yildirim | ver";
            player.sendMessage(new TextComponentString("\u00a7e[" + NAME + "] \u00a7f" + msg + " \u00a77(Can: "
                    + (int) getHealth() + "/" + (int) getMaxHealth() + ")"));
        }
        return true;
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource s) { return SoundEvents.ENTITY_PLAYER_HURT; }

    @Override
    protected SoundEvent getDeathSound() { return SoundEvents.ENTITY_PLAYER_DEATH; }

    @Override
    public void writeEntityToNBT(NBTTagCompound c) {
        super.writeEntityToNBT(c);
        c.setInteger("NpcMode", mode.ordinal());
        c.setInteger("NpcElement", element.ordinal());
        if (commander != null) c.setUniqueId("NpcCommander", commander);
        NBTTagList list = new NBTTagList();
        for (int i = 0; i < inventory.getSizeInventory(); i++) {
            ItemStack s = inventory.getStackInSlot(i);
            if (!s.isEmpty()) {
                NBTTagCompound t = new NBTTagCompound();
                t.setByte("Slot", (byte) i);
                s.writeToNBT(t);
                list.appendTag(t);
            }
        }
        c.setTag("NpcInv", list);
    }

    @Override
    public void readEntityFromNBT(NBTTagCompound c) {
        super.readEntityFromNBT(c);
        int m = c.getInteger("NpcMode");
        mode = (m >= 0 && m < Mode.values().length) ? Mode.values()[m] : Mode.IDLE;
        if (c.hasUniqueId("NpcCommander")) commander = c.getUniqueId("NpcCommander");
        int el = c.getInteger("NpcElement");
        if (el >= 0 && el < Element.values().length) element = Element.values()[el];
        NBTTagList list = c.getTagList("NpcInv", 10);
        for (int i = 0; i < list.tagCount(); i++) {
            NBTTagCompound t = list.getCompoundTagAt(i);
            int slot = t.getByte("Slot") & 255;
            if (slot < inventory.getSizeInventory()) inventory.setInventorySlotContents(slot, new ItemStack(t));
        }
        updateHeldItem();
        setCustomNameTag(NAME);
    }
}

package com.colorverse;

import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.util.math.MathHelper;
import net.minecraftforge.client.IRenderHandler;

// Gokyuzunu ayarlardaki renge boyar (gece kararir)
public class ColorSkyRenderer {
    public static final IRenderHandler INSTANCE = new IRenderHandler() {
        @Override
        public void render(float partialTicks, WorldClient world, Minecraft mc) {
            draw(partialTicks, world);
        }
    };

    static void draw(float pt, WorldClient world) {
        float br = 0.25F + 0.75F * MathHelper.clamp(world.getSunBrightness(pt), 0.0F, 1.0F);
        int c = ColorSettings.color[2];
        float r = ((c >> 16) & 255) / 255.0F * br, g = ((c >> 8) & 255) / 255.0F * br, b = (c & 255) / 255.0F * br;

        GlStateManager.disableTexture2D();
        GlStateManager.disableFog();
        GlStateManager.disableAlpha();
        GlStateManager.disableCull();
        GlStateManager.depthMask(false);

        Tessellator t = Tessellator.getInstance();
        BufferBuilder bb = t.getBuffer();
        bb.begin(7, DefaultVertexFormats.POSITION_COLOR);
        double s = 150.0D;
        q(bb, -s, -s, -s, s, -s, -s, s, -s, s, -s, -s, s, r, g, b);
        q(bb, -s, s, -s, -s, s, s, s, s, s, s, s, -s, r, g, b);
        q(bb, -s, -s, -s, -s, s, -s, s, s, -s, s, -s, -s, r, g, b);
        q(bb, -s, -s, s, s, -s, s, s, s, s, -s, s, s, r, g, b);
        q(bb, -s, -s, -s, -s, -s, s, -s, s, s, -s, s, -s, r, g, b);
        q(bb, s, -s, -s, s, s, -s, s, s, s, s, -s, s, r, g, b);
        t.draw();

        GlStateManager.depthMask(true);
        GlStateManager.enableCull();
        GlStateManager.enableAlpha();
        GlStateManager.enableFog();
        GlStateManager.enableTexture2D();
    }

    private static void q(BufferBuilder bb, double x1, double y1, double z1, double x2, double y2, double z2,
                          double x3, double y3, double z3, double x4, double y4, double z4, float r, float g, float b) {
        bb.pos(x1, y1, z1).color(r, g, b, 1.0F).endVertex();
        bb.pos(x2, y2, z2).color(r, g, b, 1.0F).endVertex();
        bb.pos(x3, y3, z3).color(r, g, b, 1.0F).endVertex();
        bb.pos(x4, y4, z4).color(r, g, b, 1.0F).endVertex();
    }
}

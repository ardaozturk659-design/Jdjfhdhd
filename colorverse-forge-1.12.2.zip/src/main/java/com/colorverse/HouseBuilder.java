package com.colorverse;

import java.util.ArrayList;
import java.util.List;

import net.minecraft.block.state.IBlockState;
import net.minecraft.init.Blocks;
import net.minecraft.item.ItemDoor;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public class HouseBuilder {
    public static class Step {
        public final BlockPos pos;
        public final IBlockState state;
        public final boolean door;

        Step(BlockPos pos, IBlockState state, boolean door) {
            this.pos = pos;
            this.state = state;
            this.door = door;
        }

        public void place(World w) {
            if (door) ItemDoor.placeDoor(w, pos, EnumFacing.NORTH, Blocks.OAK_DOOR, false);
            else w.setBlockState(pos, state, 3);
        }
    }

    // 9x9 alani temizle, altini doldur. o = zemin kosesi
    public static void clearArea(World w, BlockPos o) {
        for (int x = 0; x <= 8; x++) {
            for (int z = 0; z <= 8; z++) {
                for (int y = 1; y <= 11; y++) {
                    BlockPos p = o.add(x, y, z);
                    if (!w.isAirBlock(p)) w.setBlockToAir(p);
                }
                BlockPos b = o.add(x, -1, z);
                if (!w.getBlockState(b).getMaterial().isSolid()) w.setBlockState(b, Blocks.COBBLESTONE.getDefaultState(), 2);
            }
        }
    }

    public static List<Step> plan(BlockPos o) {
        List<Step> l = new ArrayList<Step>();
        IBlockState planks = Blocks.PLANKS.getDefaultState();
        IBlockState log = Blocks.LOG.getDefaultState();
        IBlockState cobble = Blocks.COBBLESTONE.getDefaultState();
        IBlockState glass = Blocks.GLASS_PANE.getDefaultState();

        // zemin
        for (int x = 0; x <= 8; x++)
            for (int z = 0; z <= 8; z++)
                l.add(new Step(o.add(x, 0, z), planks, false));

        // duvarlar
        for (int y = 1; y <= 4; y++) {
            for (int x = 0; x <= 8; x++) {
                for (int z = 0; z <= 8; z++) {
                    boolean edge = x == 0 || x == 8 || z == 0 || z == 8;
                    if (!edge) continue;
                    if (x == 4 && z == 0 && y <= 2) continue; // kapi bosluğu
                    boolean corner = (x == 0 || x == 8) && (z == 0 || z == 8);
                    IBlockState s = corner ? log : (y == 1 ? cobble : planks);
                    boolean window = (y == 2 || y == 3)
                            && (((z == 0 || z == 8) && (x == 2 || x == 6)) || ((x == 0 || x == 8) && (z == 2 || z == 6)));
                    if (window) s = glass;
                    l.add(new Step(o.add(x, y, z), s, false));
                }
            }
        }
        l.add(new Step(o.add(4, 1, 0), null, true)); // kapi

        // ic esyalar
        l.add(new Step(o.add(1, 1, 1), Blocks.TORCH.getDefaultState(), false));
        l.add(new Step(o.add(7, 1, 1), Blocks.TORCH.getDefaultState(), false));
        l.add(new Step(o.add(1, 1, 7), Blocks.TORCH.getDefaultState(), false));
        l.add(new Step(o.add(7, 1, 7), Blocks.TORCH.getDefaultState(), false));
        l.add(new Step(o.add(1, 1, 4), Blocks.CRAFTING_TABLE.getDefaultState(), false));
        l.add(new Step(o.add(7, 1, 4), Blocks.FURNACE.getDefaultState(), false));
        l.add(new Step(o.add(4, 1, 7), Blocks.CHEST.getDefaultState(), false));

        // piramit cati
        for (int i = 0; i <= 4; i++) {
            for (int x = i; x <= 8 - i; x++)
                for (int z = i; z <= 8 - i; z++)
                    l.add(new Step(o.add(x, 5 + i, z), planks, false));
        }
        return l;
    }
}

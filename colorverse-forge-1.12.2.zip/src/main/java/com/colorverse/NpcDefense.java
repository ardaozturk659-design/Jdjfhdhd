package com.colorverse;

import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

// Komutani biri vurursa / olduruurse Bot o kisiye saldirir
@Mod.EventBusSubscriber(modid = ColorVerse.MODID)
public class NpcDefense {
    @SubscribeEvent
    public static void onHurt(LivingHurtEvent e) {
        if (!(e.getEntityLiving() instanceof EntityPlayerMP)) return;
        EntityPlayerMP victim = (EntityPlayerMP) e.getEntityLiving();
        Entity src = e.getSource().getTrueSource();
        if (!(src instanceof EntityLivingBase) || src == victim || src instanceof EntityNpc) return;
        for (Entity ent : victim.world.loadedEntityList) {
            if (!(ent instanceof EntityNpc)) continue;
            EntityNpc n = (EntityNpc) ent;
            if (victim.getUniqueID().equals(n.getCommanderId())
                    && n.getMode() != EntityNpc.Mode.STAY
                    && n.getAttackTarget() == null
                    && n.getDistanceSq(victim) < 1600.0D) {
                n.setAttackTarget((EntityLivingBase) src);
            }
        }
    }
}

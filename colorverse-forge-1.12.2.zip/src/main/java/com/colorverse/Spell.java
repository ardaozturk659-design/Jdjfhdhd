package com.colorverse;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

// 28 buyu: her elementte 4 tane
public enum Spell {
    // ATES
    FIREBALL(Element.FIRE, "Ate\u015f Topu", 30, true),
    FLAME_BURST(Element.FIRE, "Alev Patlamas\u0131", 35, true),
    FIRE_NOVA(Element.FIRE, "Ate\u015f Dalgas\u0131", 60, true),
    METEOR(Element.FIRE, "Meteor Ya\u011fmuru", 100, true),
    // BUZ
    ICE_BEAM(Element.ICE, "Buz I\u015f\u0131n\u0131", 25, true),
    FROST_NOVA(Element.ICE, "Don Dalgas\u0131", 60, true),
    BLIZZARD(Element.ICE, "Kar F\u0131rt\u0131nas\u0131", 100, true),
    ICE_ARMOR(Element.ICE, "Buz Z\u0131rh\u0131", 200, false),
    // ELEKTRIK
    CHAIN_LIGHTNING(Element.ELECTRIC, "Zincir Elektrik", 30, true),
    STATIC_SHOCK(Element.ELECTRIC, "Elektrik \u015eoku", 60, true),
    ARC_FLASH(Element.ELECTRIC, "Ark Parlamas\u0131", 50, true),
    OVERCHARGE(Element.ELECTRIC, "A\u015f\u0131r\u0131 Y\u00fck", 200, false),
    // SIMSEK
    LIGHTNING_STRIKE(Element.LIGHTNING, "\u015eim\u015fek", 60, true),
    STORM(Element.LIGHTNING, "F\u0131rt\u0131na", 140, true),
    THUNDER_CLAP(Element.LIGHTNING, "G\u00f6k G\u00fcr\u00fclt\u00fcs\u00fc", 80, true),
    LIGHTNING_DASH(Element.LIGHTNING, "\u015eim\u015fek At\u0131l\u0131\u015f\u0131", 60, false),
    // SU
    WATER_WAVE(Element.WATER, "Su Dalgas\u0131", 30, true),
    HEALING_SPRING(Element.WATER, "\u015eifa P\u0131nar\u0131", 120, false),
    TIDAL_BURST(Element.WATER, "Med C\u00fczir", 70, true),
    AQUA_SHIELD(Element.WATER, "Su Kalkan\u0131", 200, false),
    // TOPRAK
    EARTHQUAKE(Element.EARTH, "Deprem", 40, true),
    STONE_SKIN(Element.EARTH, "Ta\u015f Deri", 200, false),
    ROCK_THROW(Element.EARTH, "Kaya F\u0131rlat", 35, true),
    QUAKE_NOVA(Element.EARTH, "Sars\u0131nt\u0131 Dalgas\u0131", 70, true),
    // KARANLIK
    SOUL_DRAIN(Element.DARK, "Ruh Emme", 35, true),
    SHADOW_NOVA(Element.DARK, "G\u00f6lge Dalgas\u0131", 70, true),
    VANISH(Element.DARK, "Kaybol", 200, false),
    BLACK_HOLE(Element.DARK, "Kara Delik", 120, true),
    // ---- YENI 10 BUYU ----
    FIRE_WALL(Element.FIRE, "Ate\u015f Duvar\u0131", 80, true),
    ICE_PRISON(Element.ICE, "Buz Hapsi", 90, true),
    SPARK_STORM(Element.ELECTRIC, "K\u0131v\u0131lc\u0131m F\u0131rt\u0131nas\u0131", 90, true),
    SKY_FURY(Element.LIGHTNING, "G\u00f6\u011f\u00fcn \u00d6fkesi", 150, true),
    WHIRLPOOL(Element.WATER, "Girdap", 100, true),
    GEYSER(Element.WATER, "Gayzer", 70, true),
    ROOT_BIND(Element.EARTH, "K\u00f6k Ba\u011f\u0131", 80, true),
    STONE_FIST(Element.EARTH, "Ta\u015f Yumruk", 50, true),
    CURSE(Element.DARK, "Lanet", 100, true),
    SHADOW_STEP(Element.DARK, "G\u00f6lge Ad\u0131m\u0131", 60, false);

    public final Element element;
    public final String title;
    public final int cooldown;
    public final boolean attack;

    Spell(Element element, String title, int cooldown, boolean attack) {
        this.element = element;
        this.title = title;
        this.cooldown = cooldown;
        this.attack = attack;
    }

    public static Spell[] of(Element e) {
        List<Spell> l = new ArrayList<Spell>();
        for (Spell s : values()) if (s.element == e) l.add(s);
        return l.toArray(new Spell[0]);
    }

    public static Spell randomAttack(Element e, Random r) {
        List<Spell> l = new ArrayList<Spell>();
        for (Spell s : values()) if (s.element == e && s.attack) l.add(s);
        return l.get(r.nextInt(l.size()));
    }

    // Turkce karakterleri sadelestir (komut/sohbet eslestirme icin)
    public static String norm(String x) {
        return x.toLowerCase(new java.util.Locale("tr", "TR"))
                .replace('\u0131', 'i').replace('\u00e7', 'c').replace('\u011f', 'g')
                .replace('\u00f6', 'o').replace('\u015f', 's').replace('\u00fc', 'u')
                .replaceAll("[^a-z0-9]", "");
    }

    // "fireball", "ates topu", "FIRE_BALL" gibi yazimlardan buyuyu bul
    public static Spell find(String q) {
        String n = norm(q);
        if (n.isEmpty()) return null;
        for (Spell sp : values()) if (norm(sp.name()).equals(n) || norm(sp.title).equals(n)) return sp;
        return null;
    }

    // cumle icinde gecen buyu adini bul (en uzun eslesme kazanir)
    public static Spell findIn(String sentence) {
        String n = norm(sentence);
        Spell best = null;
        int bl = 0;
        for (Spell sp : values()) {
            String a = norm(sp.name()), b = norm(sp.title);
            if (n.contains(a) && a.length() > bl) { best = sp; bl = a.length(); }
            if (n.contains(b) && b.length() > bl) { best = sp; bl = b.length(); }
        }
        return best;
    }
}

package com.colorverse;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import net.minecraft.block.Block;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.effect.EntityLightningBolt;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.projectile.EntityLargeFireball;
import net.minecraft.init.Blocks;
import net.minecraft.init.MobEffects;
import net.minecraft.init.SoundEvents;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.SoundEvent;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import net.minecraft.world.WorldServer;

// Butun buyuler burada. Hem oyuncu asalari hem Bot kullanir.
public class SpellCasting {
    private static class Hit {
        EntityLivingBase entity;
        Vec3d pos;
    }

    public static void cast(Spell sp, EntityLivingBase c, Vec3d dir) {
        World w = c.world;
        if (w.isRemote || dir.lengthSquared() < 1.0E-6D) return;
        dir = dir.normalize();
        Vec3d eye = c.getPositionEyes(1.0F);
        Vec3d start = eye.add(dir.x * 0.8D, dir.y * 0.8D - 0.2D, dir.z * 0.8D);
        Vec3d self = c.getPositionVector().add(0.0D, 1.0D, 0.0D);
        switch (sp) {
            case FIREBALL: fire(c, start, dir); break;
            case FLAME_BURST: flameBurst(c, start, dir); break;
            case FIRE_NOVA: fireNova(c, self); break;
            case METEOR: meteor(c, start, dir); break;
            case ICE_BEAM: ice(c, start, dir); break;
            case FROST_NOVA: frostNova(c, self); break;
            case BLIZZARD: blizzard(c, start, dir); break;
            case ICE_ARMOR: iceArmor(c, self); break;
            case CHAIN_LIGHTNING: electric(c, start, dir); break;
            case STATIC_SHOCK: staticShock(c, self); break;
            case ARC_FLASH: arcFlash(c, start, dir); break;
            case OVERCHARGE: overcharge(c, self); break;
            case LIGHTNING_STRIKE: lightning(c, start, dir); break;
            case STORM: storm(c, start, dir); break;
            case THUNDER_CLAP: thunderClap(c, self); break;
            case LIGHTNING_DASH: dash(c, self, dir); break;
            case WATER_WAVE: water(c, start, dir); break;
            case HEALING_SPRING: healingSpring(c, self); break;
            case TIDAL_BURST: tidalBurst(c, start, dir); break;
            case AQUA_SHIELD: aquaShield(c, self); break;
            case EARTHQUAKE: earth(c, start, dir); break;
            case STONE_SKIN: stoneSkin(c, self); break;
            case ROCK_THROW: rockThrow(c, start, dir); break;
            case QUAKE_NOVA: quakeNova(c, self); break;
            case SOUL_DRAIN: dark(c, start, dir); break;
            case SHADOW_NOVA: shadowNova(c, self); break;
            case VANISH: vanish(c, self); break;
            case FIRE_WALL: fireWall(c, start, dir); break;
            case ICE_PRISON: icePrison(c, start, dir); break;
            case SPARK_STORM: sparkStorm(c, self); break;
            case SKY_FURY: skyFury(c, start, dir); break;
            case WHIRLPOOL: whirlpool(c, start, dir); break;
            case GEYSER: geyser(c, start, dir); break;
            case ROOT_BIND: rootBind(c, start, dir); break;
            case STONE_FIST: stoneFist(c, start, dir); break;
            case CURSE: curse(c, start, dir); break;
            case SHADOW_STEP: shadowStep(c, start, dir); break;
            default: blackHole(c, start, dir); break;
        }
    }

    // ---------- yardimcilar ----------
    private static DamageSource src(EntityLivingBase c) {
        return c instanceof EntityPlayer ? DamageSource.causePlayerDamage((EntityPlayer) c) : DamageSource.causeMobDamage(c);
    }

    private static boolean canHit(EntityLivingBase c, Entity e) {
        if (!(e instanceof EntityLivingBase) || e == c || !e.isEntityAlive() || e instanceof EntityNpc) return false;
        if (c instanceof EntityNpc && e instanceof EntityPlayer) return false;
        return true;
    }

    private static Vec3d mid(Entity e) {
        return new Vec3d(e.posX, e.posY + e.height / 2.0D, e.posZ);
    }

    private static void sound(EntityLivingBase c, SoundEvent s, float vol, float pitch) {
        c.world.playSound(null, c.posX, c.posY, c.posZ, s, SoundCategory.PLAYERS, vol, pitch);
    }

    private static void fx(EntityLivingBase e, Potion p, int dur, int amp) {
        e.addPotionEffect(new PotionEffect(p, dur, amp));
    }

    private static void burst(World w, EnumParticleTypes t, Vec3d p, int count, double spread, int... args) {
        if (w instanceof WorldServer) ((WorldServer) w).spawnParticle(t, p.x, p.y, p.z, count, spread, spread, spread, 0.02D, args);
    }

    private static void line(World w, EnumParticleTypes t, Vec3d a, Vec3d b, int... args) {
        if (!(w instanceof WorldServer)) return;
        Vec3d diff = b.subtract(a);
        double len = Math.sqrt(diff.lengthSquared());
        if (len < 0.01D) return;
        Vec3d d = diff.normalize();
        int n = (int) (len * 3.0D);
        for (int i = 0; i <= n; i++) {
            double k = i / 3.0D;
            ((WorldServer) w).spawnParticle(t, a.x + d.x * k, a.y + d.y * k, a.z + d.z * k, 1, 0.04D, 0.04D, 0.04D, 0.0D, args);
        }
    }

    private static void ring(World w, EnumParticleTypes t, Vec3d center, double r, int... args) {
        int pts = (int) (r * 8.0D);
        for (int i = 0; i < pts; i++) {
            double a = Math.PI * 2.0D * i / pts;
            burst(w, t, new Vec3d(center.x + Math.cos(a) * r, center.y - 0.5D, center.z + Math.sin(a) * r), 1, 0.05D, args);
        }
    }

    private static List<EntityLivingBase> near(EntityLivingBase c, Vec3d center, double r) {
        List<EntityLivingBase> out = new ArrayList<EntityLivingBase>();
        AxisAlignedBB box = new AxisAlignedBB(center.x - r, center.y - r, center.z - r, center.x + r, center.y + r, center.z + r);
        for (Entity e : c.world.getEntitiesWithinAABBExcludingEntity(c, box)) {
            if (canHit(c, e) && e.getDistanceSq(center.x, center.y, center.z) <= r * r) out.add((EntityLivingBase) e);
        }
        return out;
    }

    // merkezin etrafindakilere hasar + geriye itme + havaya kaldirma
    private static List<EntityLivingBase> nova(EntityLivingBase c, Vec3d center, double r, float dmg, double knock, double up) {
        List<EntityLivingBase> l = near(c, center, r);
        for (EntityLivingBase e : l) {
            if (dmg > 0.0F) e.attackEntityFrom(src(c), dmg);
            double ax = e.posX - center.x, az = e.posZ - center.z;
            double len = Math.sqrt(ax * ax + az * az);
            if (len > 0.01D && knock > 0.0D) { e.motionX += ax / len * knock; e.motionZ += az / len * knock; }
            if (up > 0.0D) e.motionY += up;
            e.velocityChanged = true;
        }
        return l;
    }

    private static Hit trace(EntityLivingBase c, Vec3d eye, Vec3d dir, double range) {
        World w = c.world;
        Vec3d end = eye.add(dir.x * range, dir.y * range, dir.z * range);
        RayTraceResult bh = w.rayTraceBlocks(eye, end, false, true, false);
        if (bh != null) {
            range = bh.hitVec.distanceTo(eye);
            end = eye.add(dir.x * range, dir.y * range, dir.z * range);
        }
        Hit h = new Hit();
        h.pos = end;
        double bd = range + 1.0D;
        AxisAlignedBB box = c.getEntityBoundingBox().expand(dir.x * range, dir.y * range, dir.z * range).grow(1.0D);
        for (Entity e : w.getEntitiesWithinAABBExcludingEntity(c, box)) {
            if (!canHit(c, e)) continue;
            AxisAlignedBB bb = e.getEntityBoundingBox().grow(e.getCollisionBorderSize() + 0.4D);
            RayTraceResult r = bb.calculateIntercept(eye, end);
            if (r != null) {
                double d = eye.distanceTo(r.hitVec);
                if (d < bd) { bd = d; h.entity = (EntityLivingBase) e; h.pos = r.hitVec; }
            }
        }
        return h;
    }

    // ================= ATES =================
    private static void fire(EntityLivingBase c, Vec3d start, Vec3d d) {
        World w = c.world;
        EntityLargeFireball fb = new EntityLargeFireball(w, c, d.x * 10.0D, d.y * 10.0D, d.z * 10.0D);
        fb.explosionPower = 1;
        fb.setPosition(start.x, start.y, start.z);
        w.spawnEntity(fb);
        sound(c, SoundEvents.ENTITY_BLAZE_SHOOT, 1.0F, 1.0F);
    }

    private static void flameBurst(EntityLivingBase c, Vec3d start, Vec3d d) {
        World w = c.world;
        for (int i = 1; i <= 9; i++) {
            burst(w, EnumParticleTypes.FLAME, start.add(d.x * i * 0.7D, d.y * i * 0.7D, d.z * i * 0.7D), 8, 0.15D + i * 0.05D);
        }
        sound(c, SoundEvents.ITEM_FIRECHARGE_USE, 1.0F, 0.9F);
        for (EntityLivingBase e : near(c, start, 7.0D)) {
            Vec3d to = mid(e).subtract(start);
            double len = Math.sqrt(to.lengthSquared());
            if (len < 0.001D || to.normalize().dotProduct(d) < 0.55D) continue;
            e.attackEntityFrom(src(c), 4.0F);
            e.setFire(5);
        }
    }

    private static void fireNova(EntityLivingBase c, Vec3d self) {
        for (double r = 1.5D; r <= 5.0D; r += 1.75D) ring(c.world, EnumParticleTypes.FLAME, self, r);
        sound(c, SoundEvents.ENTITY_BLAZE_SHOOT, 1.0F, 0.6F);
        for (EntityLivingBase e : nova(c, self, 5.0D, 4.0F, 0.9D, 0.3D)) e.setFire(4);
    }

    private static void meteor(EntityLivingBase c, Vec3d start, Vec3d d) {
        World w = c.world;
        Vec3d p = trace(c, start, d, 40.0D).pos;
        for (int i = 0; i < 3; i++) {
            EntityLargeFireball fb = new EntityLargeFireball(w, c, 0.0D, -10.0D, 0.0D);
            fb.explosionPower = 1;
            fb.setPosition(p.x + (w.rand.nextDouble() - 0.5D) * 5.0D, p.y + 14.0D + i * 2.0D, p.z + (w.rand.nextDouble() - 0.5D) * 5.0D);
            w.spawnEntity(fb);
        }
        sound(c, SoundEvents.ENTITY_BLAZE_SHOOT, 1.0F, 0.5F);
    }

    // ================= BUZ =================
    private static void ice(EntityLivingBase c, Vec3d start, Vec3d d) {
        World w = c.world;
        Hit h = trace(c, start, d, 24.0D);
        line(w, EnumParticleTypes.SNOW_SHOVEL, start, h.pos);
        burst(w, EnumParticleTypes.CLOUD, h.pos, 20, 0.4D);
        sound(c, SoundEvents.BLOCK_GLASS_BREAK, 1.0F, 1.5F);
        if (h.entity != null) {
            h.entity.attackEntityFrom(src(c), 4.0F);
            fx(h.entity, MobEffects.SLOWNESS, 100, 5);
            fx(h.entity, MobEffects.WEAKNESS, 100, 1);
        }
    }

    private static void frostNova(EntityLivingBase c, Vec3d self) {
        for (double r = 1.5D; r <= 6.0D; r += 1.5D) ring(c.world, EnumParticleTypes.SNOW_SHOVEL, self, r);
        burst(c.world, EnumParticleTypes.CLOUD, self, 30, 1.5D);
        sound(c, SoundEvents.BLOCK_GLASS_BREAK, 1.0F, 0.8F);
        for (EntityLivingBase e : nova(c, self, 6.0D, 3.0F, 0.4D, 0.1D)) fx(e, MobEffects.SLOWNESS, 80, 4);
    }

    private static void blizzard(EntityLivingBase c, Vec3d start, Vec3d d) {
        World w = c.world;
        Vec3d p = trace(c, start, d, 24.0D).pos;
        burst(w, EnumParticleTypes.SNOW_SHOVEL, p.add(0.0D, 2.0D, 0.0D), 90, 2.2D);
        burst(w, EnumParticleTypes.CLOUD, p, 20, 1.5D);
        sound(c, SoundEvents.ENTITY_PLAYER_SPLASH, 0.8F, 0.6F);
        for (EntityLivingBase e : near(c, p, 5.0D)) {
            e.attackEntityFrom(src(c), 3.0F);
            fx(e, MobEffects.SLOWNESS, 80, 3);
        }
    }

    private static void iceArmor(EntityLivingBase c, Vec3d self) {
        fx(c, MobEffects.RESISTANCE, 300, 1);
        fx(c, MobEffects.ABSORPTION, 300, 1);
        burst(c.world, EnumParticleTypes.CLOUD, self, 30, 0.6D);
        sound(c, SoundEvents.BLOCK_GLASS_BREAK, 0.8F, 1.2F);
    }

    // ================= ELEKTRIK =================
    private static void electric(EntityLivingBase c, Vec3d start, Vec3d d) {
        World w = c.world;
        Hit h = trace(c, start, d, 24.0D);
        line(w, EnumParticleTypes.FIREWORKS_SPARK, start, h.pos);
        sound(c, SoundEvents.ENTITY_LIGHTNING_IMPACT, 0.6F, 1.8F);
        Set<Entity> hit = new HashSet<Entity>();
        EntityLivingBase cur = h.entity;
        for (int i = 0; i < 5 && cur != null; i++) {
            hit.add(cur);
            cur.attackEntityFrom(src(c), 5.0F);
            EntityLivingBase next = null;
            double bd = 49.0D;
            for (Entity e : w.getEntitiesWithinAABBExcludingEntity(cur, cur.getEntityBoundingBox().grow(7.0D))) {
                if (hit.contains(e) || !canHit(c, e)) continue;
                double dd = e.getDistanceSq(cur);
                if (dd < bd) { bd = dd; next = (EntityLivingBase) e; }
            }
            if (next != null) line(w, EnumParticleTypes.FIREWORKS_SPARK, mid(cur), mid(next));
            cur = next;
        }
    }

    private static void staticShock(EntityLivingBase c, Vec3d self) {
        burst(c.world, EnumParticleTypes.FIREWORKS_SPARK, self, 60, 2.0D);
        sound(c, SoundEvents.ENTITY_LIGHTNING_IMPACT, 0.8F, 1.6F);
        for (EntityLivingBase e : nova(c, self, 4.0D, 5.0F, 0.5D, 0.15D)) fx(e, MobEffects.WEAKNESS, 100, 0);
    }

    private static void arcFlash(EntityLivingBase c, Vec3d start, Vec3d d) {
        World w = c.world;
        Hit h = trace(c, start, d, 28.0D);
        line(w, EnumParticleTypes.END_ROD, start, h.pos);
        line(w, EnumParticleTypes.FIREWORKS_SPARK, start, h.pos);
        sound(c, SoundEvents.ENTITY_LIGHTNING_IMPACT, 0.8F, 2.0F);
        if (h.entity != null) {
            h.entity.attackEntityFrom(src(c), 8.0F);
            fx(h.entity, MobEffects.BLINDNESS, 40, 0);
        }
    }

    private static void overcharge(EntityLivingBase c, Vec3d self) {
        fx(c, MobEffects.SPEED, 300, 2);
        fx(c, MobEffects.HASTE, 300, 1);
        fx(c, MobEffects.STRENGTH, 300, 0);
        burst(c.world, EnumParticleTypes.FIREWORKS_SPARK, self, 40, 0.6D);
        sound(c, SoundEvents.ENTITY_LIGHTNING_IMPACT, 0.6F, 2.0F);
    }

    // ================= SIMSEK =================
    private static void lightning(EntityLivingBase c, Vec3d start, Vec3d d) {
        Hit h = trace(c, start, d, 48.0D);
        double x = h.entity != null ? h.entity.posX : h.pos.x;
        double y = h.entity != null ? h.entity.posY : h.pos.y;
        double z = h.entity != null ? h.entity.posZ : h.pos.z;
        if (c.getDistanceSq(x, y, z) < 16.0D) return; // kendine yakin dusurme
        c.world.addWeatherEffect(new EntityLightningBolt(c.world, x, y, z, false));
    }

    private static void storm(EntityLivingBase c, Vec3d start, Vec3d d) {
        World w = c.world;
        Vec3d p = trace(c, start, d, 40.0D).pos;
        for (int i = 0; i < 5; i++) {
            double bx = p.x + (w.rand.nextDouble() - 0.5D) * 10.0D;
            double bz = p.z + (w.rand.nextDouble() - 0.5D) * 10.0D;
            if (c.getDistanceSq(bx, p.y, bz) < 25.0D) continue;
            w.addWeatherEffect(new EntityLightningBolt(w, bx, p.y, bz, false));
        }
    }

    private static void thunderClap(EntityLivingBase c, Vec3d self) {
        for (double r = 1.5D; r <= 6.0D; r += 1.5D) ring(c.world, EnumParticleTypes.EXPLOSION_LARGE, self, r);
        sound(c, SoundEvents.ENTITY_LIGHTNING_THUNDER, 0.8F, 1.2F);
        nova(c, self, 6.0D, 6.0F, 1.4D, 0.5D);
    }

    private static void dash(EntityLivingBase c, Vec3d self, Vec3d d) {
        World w = c.world;
        line(w, EnumParticleTypes.FIREWORKS_SPARK, self, self.add(d.x * 6.0D, d.y * 6.0D, d.z * 6.0D));
        for (EntityLivingBase e : near(c, self.add(d.x * 3.0D, d.y * 3.0D, d.z * 3.0D), 3.0D)) e.attackEntityFrom(src(c), 4.0F);
        c.motionX = d.x * 2.0D;
        c.motionY = Math.max(d.y * 2.0D, 0.25D);
        c.motionZ = d.z * 2.0D;
        c.velocityChanged = true;
        c.fallDistance = 0.0F;
        sound(c, SoundEvents.ENTITY_LIGHTNING_IMPACT, 0.7F, 1.9F);
    }

    // ================= SU =================
    private static void water(EntityLivingBase c, Vec3d start, Vec3d d) {
        World w = c.world;
        for (int i = 1; i <= 10; i++) {
            burst(w, EnumParticleTypes.WATER_SPLASH, start.add(d.x * i * 0.7D, d.y * i * 0.7D, d.z * i * 0.7D), 12, 0.25D + i * 0.05D);
        }
        sound(c, SoundEvents.ENTITY_PLAYER_SPLASH, 1.0F, 1.0F);
        for (EntityLivingBase e : near(c, start, 8.0D)) {
            Vec3d to = mid(e).subtract(start);
            double dist = Math.sqrt(to.lengthSquared());
            if (dist < 0.001D || to.normalize().dotProduct(d) < 0.6D) continue;
            e.attackEntityFrom(src(c), 2.0F);
            e.motionX += d.x * 1.6D;
            e.motionY += 0.45D;
            e.motionZ += d.z * 1.6D;
            e.velocityChanged = true;
            e.extinguish();
            fx(e, MobEffects.SLOWNESS, 40, 1);
        }
    }

    private static void healingSpring(EntityLivingBase c, Vec3d self) {
        World w = c.world;
        ring(w, EnumParticleTypes.WATER_SPLASH, self, 2.0D);
        ring(w, EnumParticleTypes.WATER_SPLASH, self, 4.0D);
        sound(c, SoundEvents.ENTITY_PLAYER_LEVELUP, 0.7F, 1.4F);
        for (EntityLivingBase e : w.getEntitiesWithinAABB(EntityLivingBase.class, c.getEntityBoundingBox().grow(7.0D))) {
            if (e == c || e instanceof EntityPlayer || e instanceof EntityNpc) {
                e.heal(8.0F);
                fx(e, MobEffects.REGENERATION, 100, 1);
                burst(w, EnumParticleTypes.HEART, mid(e).add(0.0D, 0.5D, 0.0D), 6, 0.4D);
            }
        }
    }

    private static void tidalBurst(EntityLivingBase c, Vec3d start, Vec3d d) {
        World w = c.world;
        Vec3d p = trace(c, start, d, 24.0D).pos;
        burst(w, EnumParticleTypes.WATER_SPLASH, p.add(0.0D, 1.0D, 0.0D), 100, 1.8D);
        sound(c, SoundEvents.ENTITY_PLAYER_SPLASH, 1.0F, 0.6F);
        for (EntityLivingBase e : nova(c, p, 4.0D, 3.0F, 0.6D, 0.9D)) e.extinguish();
    }

    private static void aquaShield(EntityLivingBase c, Vec3d self) {
        fx(c, MobEffects.WATER_BREATHING, 600, 0);
        fx(c, MobEffects.FIRE_RESISTANCE, 600, 0);
        fx(c, MobEffects.RESISTANCE, 200, 0);
        c.extinguish();
        burst(c.world, EnumParticleTypes.WATER_SPLASH, self, 40, 0.7D);
        sound(c, SoundEvents.ENTITY_PLAYER_SPLASH, 0.7F, 1.4F);
    }

    // ================= TOPRAK =================
    private static void earth(EntityLivingBase c, Vec3d start, Vec3d d) {
        World w = c.world;
        Hit h = trace(c, start, d, 20.0D);
        Vec3d p = h.pos;
        burst(w, EnumParticleTypes.BLOCK_CRACK, p, 40, 0.6D, Block.getStateId(Blocks.DIRT.getDefaultState()));
        sound(c, SoundEvents.ENTITY_GENERIC_EXPLODE, 0.6F, 0.6F);
        for (EntityLivingBase e : near(c, p, 3.0D)) {
            e.attackEntityFrom(src(c), 5.0F);
            e.motionY = 1.0D;
            e.velocityChanged = true;
            fx(e, MobEffects.SLOWNESS, 60, 2);
        }
    }

    private static void stoneSkin(EntityLivingBase c, Vec3d self) {
        fx(c, MobEffects.RESISTANCE, 200, 2);
        fx(c, MobEffects.SLOWNESS, 200, 0);
        burst(c.world, EnumParticleTypes.BLOCK_CRACK, self, 40, 0.6D, Block.getStateId(Blocks.STONE.getDefaultState()));
        sound(c, SoundEvents.ENTITY_GENERIC_EXPLODE, 0.4F, 1.2F);
    }

    private static void rockThrow(EntityLivingBase c, Vec3d start, Vec3d d) {
        World w = c.world;
        Hit h = trace(c, start, d, 24.0D);
        int stone = Block.getStateId(Blocks.STONE.getDefaultState());
        line(w, EnumParticleTypes.BLOCK_CRACK, start, h.pos, stone);
        burst(w, EnumParticleTypes.BLOCK_CRACK, h.pos, 30, 0.5D, stone);
        sound(c, SoundEvents.ENTITY_GENERIC_EXPLODE, 0.5F, 1.4F);
        if (h.entity != null) {
            h.entity.attackEntityFrom(src(c), 8.0F);
            h.entity.motionX += d.x * 1.2D;
            h.entity.motionY += 0.3D;
            h.entity.motionZ += d.z * 1.2D;
            h.entity.velocityChanged = true;
        }
    }

    private static void quakeNova(EntityLivingBase c, Vec3d self) {
        int dirt = Block.getStateId(Blocks.DIRT.getDefaultState());
        for (double r = 1.5D; r <= 6.0D; r += 1.5D) ring(c.world, EnumParticleTypes.BLOCK_CRACK, self, r, dirt);
        sound(c, SoundEvents.ENTITY_GENERIC_EXPLODE, 0.8F, 0.5F);
        for (EntityLivingBase e : nova(c, self, 6.0D, 4.0F, 0.6D, 0.8D)) fx(e, MobEffects.SLOWNESS, 60, 1);
    }

    // ================= KARANLIK =================
    private static void dark(EntityLivingBase c, Vec3d start, Vec3d d) {
        World w = c.world;
        Hit h = trace(c, start, d, 24.0D);
        line(w, EnumParticleTypes.PORTAL, start, h.pos);
        burst(w, EnumParticleTypes.SMOKE_LARGE, h.pos, 15, 0.4D);
        sound(c, SoundEvents.ENTITY_ENDERMEN_TELEPORT, 0.8F, 0.6F);
        if (h.entity != null) {
            h.entity.attackEntityFrom(DamageSource.causeIndirectMagicDamage(c, c), 6.0F);
            fx(h.entity, MobEffects.WITHER, 100, 1);
            fx(h.entity, MobEffects.BLINDNESS, 60, 0);
            c.heal(3.0F);
        }
    }

    private static void shadowNova(EntityLivingBase c, Vec3d self) {
        for (double r = 1.5D; r <= 5.0D; r += 1.75D) ring(c.world, EnumParticleTypes.SMOKE_LARGE, self, r);
        burst(c.world, EnumParticleTypes.PORTAL, self, 60, 2.0D);
        sound(c, SoundEvents.ENTITY_ENDERMEN_TELEPORT, 0.8F, 0.5F);
        for (EntityLivingBase e : nova(c, self, 5.0D, 3.0F, 0.4D, 0.1D)) {
            fx(e, MobEffects.BLINDNESS, 80, 0);
            fx(e, MobEffects.WITHER, 60, 0);
        }
    }

    private static void vanish(EntityLivingBase c, Vec3d self) {
        fx(c, MobEffects.INVISIBILITY, 200, 0);
        fx(c, MobEffects.SPEED, 200, 1);
        burst(c.world, EnumParticleTypes.SMOKE_LARGE, self, 40, 0.6D);
        sound(c, SoundEvents.ENTITY_ENDERMEN_TELEPORT, 0.8F, 1.0F);
    }

    private static void blackHole(EntityLivingBase c, Vec3d start, Vec3d d) {
        World w = c.world;
        Vec3d p = trace(c, start, d, 24.0D).pos;
        burst(w, EnumParticleTypes.PORTAL, p, 80, 2.0D);
        burst(w, EnumParticleTypes.SMOKE_LARGE, p, 10, 0.6D);
        sound(c, SoundEvents.ENTITY_ENDERMEN_TELEPORT, 1.0F, 0.4F);
        for (EntityLivingBase e : near(c, p, 7.0D)) {
            Vec3d to = p.subtract(mid(e));
            double len = Math.sqrt(to.lengthSquared());
            if (len > 0.3D) {
                e.motionX += to.x / len * 0.9D;
                e.motionY += to.y / len * 0.5D;
                e.motionZ += to.z / len * 0.9D;
                e.velocityChanged = true;
            }
            e.attackEntityFrom(DamageSource.causeIndirectMagicDamage(c, c), 2.0F);
            fx(e, MobEffects.WITHER, 40, 0);
        }
    }

    // ================= YENI BUYULER =================
    private static void fireWall(EntityLivingBase c, Vec3d start, Vec3d d) {
        World w = c.world;
        boolean grief = w.getGameRules().getBoolean("mobGriefing");
        Vec3d h = new Vec3d(d.x, 0.0D, d.z);
        if (h.lengthSquared() < 1.0E-4D) h = new Vec3d(1.0D, 0.0D, 0.0D);
        h = h.normalize();
        for (int i = 2; i <= 12; i++) {
            Vec3d p = new Vec3d(c.posX + h.x * i, c.posY + 0.5D, c.posZ + h.z * i);
            burst(w, EnumParticleTypes.FLAME, p.add(0.0D, 0.6D, 0.0D), 12, 0.35D);
            burst(w, EnumParticleTypes.LAVA, p, 2, 0.3D);
            for (EntityLivingBase e : near(c, p, 1.6D)) { e.attackEntityFrom(src(c), 4.0F); e.setFire(6); }
            if (grief) {
                net.minecraft.util.math.BlockPos bp = new net.minecraft.util.math.BlockPos(p.x, p.y, p.z);
                if (w.isAirBlock(bp) && Blocks.FIRE.canPlaceBlockAt(w, bp)) w.setBlockState(bp, Blocks.FIRE.getDefaultState());
            }
        }
        sound(c, SoundEvents.ITEM_FIRECHARGE_USE, 1.0F, 0.6F);
    }

    private static void icePrison(EntityLivingBase c, Vec3d start, Vec3d d) {
        Vec3d p = trace(c, start, d, 24.0D).pos;
        burst(c.world, EnumParticleTypes.SNOW_SHOVEL, p, 60, 1.2D);
        burst(c.world, EnumParticleTypes.WATER_WAKE, p, 30, 1.0D);
        sound(c, SoundEvents.BLOCK_GLASS_BREAK, 1.0F, 0.6F);
        for (EntityLivingBase e : near(c, p, 3.5D)) {
            e.attackEntityFrom(src(c), 3.0F);
            fx(e, MobEffects.SLOWNESS, 140, 6);
            fx(e, MobEffects.MINING_FATIGUE, 140, 2);
            fx(e, MobEffects.WEAKNESS, 140, 1);
        }
    }

    private static void sparkStorm(EntityLivingBase c, Vec3d self) {
        World w = c.world;
        ring(w, EnumParticleTypes.CRIT_MAGIC, self, 4.0D);
        ring(w, EnumParticleTypes.CRIT_MAGIC, self, 8.0D);
        sound(c, SoundEvents.ENTITY_LIGHTNING_IMPACT, 0.6F, 1.8F);
        List<EntityLivingBase> l = near(c, self, 8.0D);
        for (int i = 0; i < Math.min(l.size(), 6); i++) {
            EntityLivingBase e = l.get(i);
            line(w, EnumParticleTypes.CRIT_MAGIC, self, mid(e));
            e.attackEntityFrom(src(c), 5.0F);
            fx(e, MobEffects.SLOWNESS, 40, 1);
        }
    }

    private static void skyFury(EntityLivingBase c, Vec3d start, Vec3d d) {
        World w = c.world;
        Vec3d p = trace(c, start, d, 40.0D).pos;
        for (int i = 0; i < 5; i++) {
            Vec3d q = new Vec3d(p.x + (w.rand.nextDouble() - 0.5D) * 8.0D, p.y, p.z + (w.rand.nextDouble() - 0.5D) * 8.0D);
            w.addWeatherEffect(new EntityLightningBolt(w, q.x, q.y, q.z, true));
            for (EntityLivingBase e : near(c, q, 2.5D)) { e.attackEntityFrom(src(c), 8.0F); e.setFire(3); }
        }
    }

    private static void whirlpool(EntityLivingBase c, Vec3d start, Vec3d d) {
        World w = c.world;
        Vec3d p = trace(c, start, d, 24.0D).pos;
        ring(w, EnumParticleTypes.WATER_SPLASH, p.add(0.0D, 0.6D, 0.0D), 2.0D);
        ring(w, EnumParticleTypes.WATER_SPLASH, p.add(0.0D, 0.6D, 0.0D), 4.0D);
        burst(w, EnumParticleTypes.WATER_BUBBLE, p, 40, 2.0D);
        sound(c, SoundEvents.ENTITY_GENERIC_SPLASH, 1.0F, 0.5F);
        for (EntityLivingBase e : near(c, p, 6.0D)) {
            Vec3d to = p.subtract(mid(e));
            double len = Math.sqrt(to.lengthSquared());
            if (len < 0.2D) continue;
            e.motionX += to.x / len * 0.5D - to.z / len * 0.6D;
            e.motionZ += to.z / len * 0.5D + to.x / len * 0.6D;
            e.motionY += 0.25D;
            e.velocityChanged = true;
            e.attackEntityFrom(src(c), 2.0F);
            fx(e, MobEffects.NAUSEA, 100, 0);
        }
    }

    private static void geyser(EntityLivingBase c, Vec3d start, Vec3d d) {
        World w = c.world;
        Vec3d p = trace(c, start, d, 24.0D).pos;
        for (int i = 0; i < 12; i++) burst(w, EnumParticleTypes.WATER_SPLASH, p.add(0.0D, i * 0.5D, 0.0D), 10, 0.3D);
        sound(c, SoundEvents.ENTITY_GENERIC_SPLASH, 1.0F, 0.7F);
        for (EntityLivingBase e : near(c, p, 2.5D)) {
            e.attackEntityFrom(src(c), 4.0F);
            e.motionY += 1.5D;
            e.velocityChanged = true;
        }
    }

    private static void rootBind(EntityLivingBase c, Vec3d start, Vec3d d) {
        Vec3d p = trace(c, start, d, 24.0D).pos;
        burst(c.world, EnumParticleTypes.VILLAGER_HAPPY, p, 50, 1.4D);
        burst(c.world, EnumParticleTypes.SLIME, p, 20, 1.0D);
        sound(c, SoundEvents.BLOCK_GRASS_BREAK, 1.0F, 0.6F);
        for (EntityLivingBase e : near(c, p, 3.5D)) {
            e.attackEntityFrom(src(c), 3.0F);
            fx(e, MobEffects.SLOWNESS, 120, 7);
            fx(e, MobEffects.WEAKNESS, 120, 1);
        }
    }

    private static void stoneFist(EntityLivingBase c, Vec3d start, Vec3d d) {
        World w = c.world;
        Hit h = trace(c, start, d, 12.0D);
        int stone = Block.getStateId(Blocks.STONE.getDefaultState());
        burst(w, EnumParticleTypes.BLOCK_CRACK, h.pos, 50, 0.6D, stone);
        burst(w, EnumParticleTypes.EXPLOSION_LARGE, h.pos, 1, 0.1D);
        sound(c, SoundEvents.BLOCK_STONE_BREAK, 1.2F, 0.5F);
        for (EntityLivingBase e : near(c, h.pos, 2.5D)) {
            e.attackEntityFrom(src(c), 10.0F);
            e.motionX += d.x * 1.8D;
            e.motionZ += d.z * 1.8D;
            e.motionY += 0.5D;
            e.velocityChanged = true;
        }
    }

    private static void curse(EntityLivingBase c, Vec3d start, Vec3d d) {
        Vec3d p = trace(c, start, d, 24.0D).pos;
        burst(c.world, EnumParticleTypes.SPELL_WITCH, p, 60, 1.2D);
        burst(c.world, EnumParticleTypes.SMOKE_LARGE, p, 10, 0.6D);
        sound(c, SoundEvents.ENTITY_WITCH_AMBIENT, 1.0F, 0.6F);
        for (EntityLivingBase e : near(c, p, 3.0D)) {
            fx(e, MobEffects.WITHER, 120, 1);
            fx(e, MobEffects.BLINDNESS, 120, 0);
            fx(e, MobEffects.WEAKNESS, 240, 1);
            fx(e, MobEffects.HUNGER, 240, 1);
        }
    }

    private static void shadowStep(EntityLivingBase c, Vec3d start, Vec3d d) {
        World w = c.world;
        Vec3d p = trace(c, start, d, 14.0D).pos;
        burst(w, EnumParticleTypes.PORTAL, c.getPositionVector().add(0.0D, 1.0D, 0.0D), 40, 0.5D);
        for (int k = 0; k <= 10; k++) {
            Vec3d q = p.subtract(d.x * 0.5D * k, d.y * 0.5D * k, d.z * 0.5D * k);
            net.minecraft.util.math.BlockPos bp = new net.minecraft.util.math.BlockPos(q.x, q.y, q.z);
            if (w.isAirBlock(bp) && w.isAirBlock(bp.up())) {
                c.setPositionAndUpdate(bp.getX() + 0.5D, bp.getY(), bp.getZ() + 0.5D);
                c.fallDistance = 0.0F;
                break;
            }
        }
        burst(w, EnumParticleTypes.PORTAL, c.getPositionVector().add(0.0D, 1.0D, 0.0D), 40, 0.5D);
        sound(c, SoundEvents.ENTITY_ENDERMEN_TELEPORT, 1.0F, 1.2F);
    }
}

package com.colorverse;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Nullable;

import net.minecraft.command.CommandBase;
import net.minecraft.command.CommandException;
import net.minecraft.command.ICommandSender;
import net.minecraft.command.WrongUsageException;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.text.TextComponentString;

// /cast <buyu> [oyuncu]   -> Electroblob's Wizardry tarzi komut
// /cast list              -> butun buyulari listeler
public class CommandCast extends CommandBase {
    private static final Map<String, Long> COOLDOWNS = new HashMap<String, Long>();

    @Override
    public String getName() { return "cast"; }

    @Override
    public List<String> getAliases() {
        List<String> a = new ArrayList<String>();
        a.add("buyu");
        return a;
    }

    @Override
    public String getUsage(ICommandSender sender) { return "/cast <buyu> [oyuncu]  |  /cast list"; }

    @Override
    public int getRequiredPermissionLevel() { return 0; }

    @Override
    public boolean checkPermission(MinecraftServer server, ICommandSender sender) { return true; }

    @Override
    public void execute(MinecraftServer server, ICommandSender sender, String[] args) throws CommandException {
        if (args.length == 0) throw new WrongUsageException(getUsage(sender));

        if (args[0].equalsIgnoreCase("list")) {
            StringBuilder sb = new StringBuilder("\u00a7bBuyuler (" + Spell.values().length + "):\n");
            for (Element el : Element.values()) {
                sb.append("\u00a7e").append(el.id).append(": \u00a7f");
                Spell[] l = Spell.of(el);
                for (int i = 0; i < l.length; i++) sb.append(l[i].name().toLowerCase()).append(i < l.length - 1 ? ", " : "");
                sb.append("\n");
            }
            sender.sendMessage(new TextComponentString(sb.toString().trim()));
            return;
        }

        Spell sp = Spell.find(args[0]);
        if (sp == null) throw new CommandException("Boyle bir buyu yok: " + args[0] + "  (/cast list ile bak)");

        EntityPlayerMP caster;
        if (args.length >= 2) {
            if (!sender.canUseCommand(2, "cast")) throw new CommandException("Baskasi adina buyu atmak icin yetki lazim.");
            caster = getPlayer(server, sender, args[1]);
        } else {
            caster = getCommandSenderAsPlayer(sender);
        }

        long now = caster.world.getTotalWorldTime();
        String key = caster.getUniqueID() + ":" + sp.name();
        Long until = COOLDOWNS.get(key);
        if (until != null && until > now) {
            double sec = (until - now) / 20.0D;
            throw new CommandException("Bekleme suresi: " + String.format("%.1f", sec) + " sn");
        }
        COOLDOWNS.put(key, now + sp.cooldown);

        SpellCasting.cast(sp, caster, caster.getLookVec());
        caster.sendStatusMessage(new TextComponentString("\u00a7b" + sp.title), true);
    }

    @Override
    public List<String> getTabCompletions(MinecraftServer server, ICommandSender sender, String[] args, @Nullable BlockPos pos) {
        if (args.length == 1) {
            List<String> names = new ArrayList<String>();
            names.add("list");
            for (Spell s : Spell.values()) names.add(s.name().toLowerCase());
            return getListOfStringsMatchingLastWord(args, names);
        }
        if (args.length == 2) return getListOfStringsMatchingLastWord(args, server.getOnlinePlayerNames());
        return new ArrayList<String>();
    }
}

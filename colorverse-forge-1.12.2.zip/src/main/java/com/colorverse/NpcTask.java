package com.colorverse;

import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.math.BlockPos;

// Botun tek bir gorevi. Mesajdaki "sonra" ile ayrilan her parca bir gorev olur.
public class NpcTask {
    public enum Kind { MODE, ELEMENT, SPELL, GIVE, BUILD, KILL, GOTO }

    public Kind kind;
    public EntityNpc.Mode mode;
    public Element element;
    public Spell spell;
    public BlockPos pos;
    public EntityLivingBase target;
    public int goal;      // kac blok/esya (0 = sinirsiz)
    public int limit;     // en fazla kac tick surer (0 = varsayilan)
    public String reply;

    public NpcTask(Kind k) { this.kind = k; }

    public static NpcTask mode(EntityNpc.Mode m, String reply) {
        NpcTask t = new NpcTask(Kind.MODE);
        t.mode = m;
        t.reply = reply;
        return t;
    }

    public void start(EntityNpc npc, EntityPlayer by) {
        npc.beginTask(this);
        if (kind == Kind.MODE && mode == null) return; // sadece sohbet
        switch (kind) {
            case MODE: npc.setMode(mode, by); break;
            case ELEMENT: npc.setSpell(element, by); break;
            case SPELL: npc.setForcedSpell(spell, by); break;
            case GIVE: npc.giveItemsTo(by); break;
            case BUILD: npc.startBuild(by); break;
            case KILL: npc.killTarget(target, by); break;
            case GOTO: npc.startGoto(pos, by); break;
        }
    }
}

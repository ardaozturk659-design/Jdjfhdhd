package com.colorverse;

import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.ActionResult;
import net.minecraft.util.EnumActionResult;
import net.minecraft.util.EnumHand;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.world.World;

public class ItemWand extends Item {
    public final Element element;

    public ItemWand(Element element) {
        this.element = element;
        String n = "wand_" + element.id;
        setRegistryName(ColorVerse.MODID, n);
        setTranslationKey(ColorVerse.MODID + "." + n);
        setMaxStackSize(1);
        setMaxDamage(250);
        setCreativeTab(CreativeTabs.COMBAT);
    }

    public Spell selected(ItemStack stack) {
        Spell[] l = Spell.of(element);
        NBTTagCompound t = stack.getTagCompound();
        int i = t == null ? 0 : t.getInteger("Spell");
        return l[Math.floorMod(i, l.length)];
    }

    @Override
    public ActionResult<ItemStack> onItemRightClick(World world, EntityPlayer player, EnumHand hand) {
        ItemStack stack = player.getHeldItem(hand);
        Spell[] l = Spell.of(element);

        if (player.isSneaking()) { // shift + sag tik: buyu degistir
            if (!world.isRemote) {
                NBTTagCompound t = stack.hasTagCompound() ? stack.getTagCompound() : new NBTTagCompound();
                t.setInteger("Spell", (t.getInteger("Spell") + 1) % l.length);
                stack.setTagCompound(t);
                player.sendStatusMessage(new TextComponentString("\u00a7bB\u00fcy\u00fc: \u00a7f" + selected(stack).title), true);
            }
            return new ActionResult<ItemStack>(EnumActionResult.SUCCESS, stack);
        }

        Spell sp = selected(stack);
        if (!world.isRemote) {
            SpellCasting.cast(sp, player, player.getLookVec());
            stack.damageItem(1, player);
            player.sendStatusMessage(new TextComponentString("\u00a7b" + sp.title), true);
        }
        player.getCooldownTracker().setCooldown(this, sp.cooldown);
        player.swingArm(hand);
        return new ActionResult<ItemStack>(EnumActionResult.SUCCESS, stack);
    }

    @Override
    public boolean hasEffect(ItemStack stack) { return true; }
}

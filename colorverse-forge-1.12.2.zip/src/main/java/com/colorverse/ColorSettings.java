package com.colorverse;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.Properties;

import net.minecraftforge.fml.common.Loader;

// Oyun ici renk ayarlari (istemci): 0 = yildirim, 1 = cimen, 2 = hava
public class ColorSettings {
    public static final String[] TAB_NAMES = {"Yildirim", "Cimen", "Hava"};
    public static final int[] DEFAULTS = {0xBFE8FF, 0x7CBD6B, 0x78A7FF};
    public static final boolean[] DEFAULT_ENABLED = {true, false, false};
    public static final int[] color = {0xBFE8FF, 0x7CBD6B, 0x78A7FF};
    public static final boolean[] enabled = {true, false, false};

    private static boolean loaded;

    private static File file() {
        File dir;
        try { dir = Loader.instance().getConfigDir(); } catch (Throwable t) { dir = new File("config"); }
        if (dir == null) dir = new File("config");
        return new File(dir, "colorverse_colors.properties");
    }

    public static void load() {
        if (loaded) return;
        loaded = true;
        try {
            File f = file();
            if (!f.exists()) return;
            Properties p = new Properties();
            FileInputStream in = new FileInputStream(f);
            try { p.load(in); } finally { in.close(); }
            for (int i = 0; i < 3; i++) {
                color[i] = Integer.parseInt(p.getProperty("color" + i, Integer.toHexString(color[i])), 16) & 0xFFFFFF;
                enabled[i] = Boolean.parseBoolean(p.getProperty("enabled" + i, String.valueOf(enabled[i])));
            }
        } catch (Exception ignored) { }
    }

    public static void save() {
        try {
            Properties p = new Properties();
            for (int i = 0; i < 3; i++) {
                p.setProperty("color" + i, Integer.toHexString(color[i]));
                p.setProperty("enabled" + i, String.valueOf(enabled[i]));
            }
            File f = file();
            f.getParentFile().mkdirs();
            FileOutputStream out = new FileOutputStream(f);
            try { p.store(out, "ColorVerse renkleri"); } finally { out.close(); }
        } catch (Exception ignored) { }
    }

    public static int lightningRgb() {
        return enabled[0] ? color[0] : 0x7373A0;
    }

    // ---- HSV <-> RGB ----
    public static int hsvToRgb(float h, float s, float v) {
        h = h - (float) Math.floor(h);
        float hh = h * 6.0F;
        int i = (int) hh;
        float f = hh - i;
        float p = v * (1.0F - s), q = v * (1.0F - f * s), t = v * (1.0F - (1.0F - f) * s);
        float r, g, b;
        switch (i % 6) {
            case 0: r = v; g = t; b = p; break;
            case 1: r = q; g = v; b = p; break;
            case 2: r = p; g = v; b = t; break;
            case 3: r = p; g = q; b = v; break;
            case 4: r = t; g = p; b = v; break;
            default: r = v; g = p; b = q; break;
        }
        return ((int) (r * 255.0F + 0.5F) << 16) | ((int) (g * 255.0F + 0.5F) << 8) | (int) (b * 255.0F + 0.5F);
    }

    public static int hsvToRgbSafe(float h, float s, float v) { return hsvToRgb(h, s, v) & 0xFFFFFF; }

    public static float[] rgbToHsv(int rgb) {
        float r = ((rgb >> 16) & 255) / 255.0F, g = ((rgb >> 8) & 255) / 255.0F, b = (rgb & 255) / 255.0F;
        float max = Math.max(r, Math.max(g, b)), min = Math.min(r, Math.min(g, b));
        float d = max - min;
        float h;
        if (d < 1.0E-6F) h = 0.0F;
        else if (max == r) h = ((g - b) / d) / 6.0F;
        else if (max == g) h = (2.0F + (b - r) / d) / 6.0F;
        else h = (4.0F + (r - g) / d) / 6.0F;
        if (h < 0.0F) h += 1.0F;
        return new float[] {h, max < 1.0E-6F ? 0.0F : d / max, max};
    }
}

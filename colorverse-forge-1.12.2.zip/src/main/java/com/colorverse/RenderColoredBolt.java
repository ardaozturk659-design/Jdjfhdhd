package com.colorverse;

import java.util.Random;

import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.entity.Render;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.entity.effect.EntityLightningBolt;
import net.minecraft.util.ResourceLocation;

// Yildirimi ayarlardaki renkte cizer (acik renk varsayilan)
public class RenderColoredBolt extends Render<EntityLightningBolt> {
    public RenderColoredBolt(RenderManager manager) { super(manager); }

    @Override
    public void doRender(EntityLightningBolt e, double x, double y, double z, float yaw, float pt) {
        int c = ColorSettings.lightningRgb();
        float r = ((c >> 16) & 255) / 255.0F, g = ((c >> 8) & 255) / 255.0F, b = (c & 255) / 255.0F;

        Tessellator t = Tessellator.getInstance();
        BufferBuilder bb = t.getBuffer();
        GlStateManager.disableTexture2D();
        GlStateManager.disableLighting();
        GlStateManager.disableCull();
        GlStateManager.enableBlend();
        GlStateManager.blendFunc(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE);
        GlStateManager.depthMask(false);

        Random rnd = new Random(e.boltVertex);
        double[] ox = new double[9], oz = new double[9];
        for (int i = 1; i <= 8; i++) {
            ox[i] = ox[i - 1] + (rnd.nextDouble() - 0.5D) * 7.0D;
            oz[i] = oz[i - 1] + (rnd.nextDouble() - 0.5D) * 7.0D;
        }

        for (int layer = 0; layer < 3; layer++) {
            double w = layer == 0 ? 0.6D : (layer == 1 ? 0.3D : 0.1D);
            float a = layer == 0 ? 0.2F : (layer == 1 ? 0.45F : 0.95F);
            float rr = layer == 2 ? Math.min(1.0F, r * 0.5F + 0.5F) : r;
            float gg = layer == 2 ? Math.min(1.0F, g * 0.5F + 0.5F) : g;
            float b2 = layer == 2 ? Math.min(1.0F, b * 0.5F + 0.5F) : b;
            bb.begin(7, DefaultVertexFormats.POSITION_COLOR);
            for (int i = 0; i < 8; i++) {
                double y0 = y + i * 16.0D, y1 = y + (i + 1) * 16.0D;
                double ax = x + ox[i], az = z + oz[i], bx = x + ox[i + 1], bz = z + oz[i + 1];
                // iki capraz serit (X ve Z duzleminde)
                bb.pos(ax - w, y0, az).color(rr, gg, b2, a).endVertex();
                bb.pos(ax + w, y0, az).color(rr, gg, b2, a).endVertex();
                bb.pos(bx + w, y1, bz).color(rr, gg, b2, a).endVertex();
                bb.pos(bx - w, y1, bz).color(rr, gg, b2, a).endVertex();
                bb.pos(ax, y0, az - w).color(rr, gg, b2, a).endVertex();
                bb.pos(ax, y0, az + w).color(rr, gg, b2, a).endVertex();
                bb.pos(bx, y1, bz + w).color(rr, gg, b2, a).endVertex();
                bb.pos(bx, y1, bz - w).color(rr, gg, b2, a).endVertex();
            }
            t.draw();
        }

        GlStateManager.depthMask(true);
        GlStateManager.disableBlend();
        GlStateManager.enableCull();
        GlStateManager.enableLighting();
        GlStateManager.enableTexture2D();
    }

    @Override
    protected ResourceLocation getEntityTexture(EntityLightningBolt entity) { return null; }
}

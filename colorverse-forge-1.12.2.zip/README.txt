KURULUM (Forge 1.12.2 MDK ile)
1) Forge 1.12.2 MDK'yi indir ve ac.
2) Bu zipteki src/main klasorunun icindekileri MDK'nin src/main klasorune kopyala.
3) gradlew build -> build/libs icinde .jar cikar, mods klasorune at.
   (test icin: gradlew runClient)

KULLANIM
- Yaratici modda "Insaat Bloklari" sekmesinde 16 renkli Portal blogu var.
- Portal blogunun ustune bas -> o rengin evrenine isinlanirsin (ID 100-115).
- Evrende (3,63,0) konumunda geri donus portali olusur; ustune basinca overworld'e donersin.
- Komutla gecis: /forge tpx 100 (beyaz) ... 115 (siyah)

NPC (BOT)
- Yaratici modda Cesitli (Misc) sekmesinde "Bot" spawn yumurtasi var. Yere tikla, Bot gelir.
- Sohbete yaz (yakinindaysa duyar):
  gel -> seni takip eder | dur -> bekler | saldir/vur -> canavarlara saldirir
  yildirim -> uzaktaki canavarlara (zombi vb.) yildirim dusurur
  odun -> agac keser | tas -> tas, komur, demir kazar | topla -> yerdeki esyalari toplar
  ates -> canavarlara ates topu atar
  ver -> topladiklarini sana verir (ya da ona sag tikla)
- Cani 40 (20 kalp), yavas yavas iyilesir. Olursa esyalarini birakir.
- Skin: src/main/resources/assets/colorverse/textures/entity/npc.png

ATES
- Sohbete yaz:  ates  (veya: darklord5456 ates)
- Bot yaklasan canavarlara (zombi vb.) ates topu atar, seni takip eder. Yangin cikarabilir, dikkat.

ISIMLE CAGIRMA
- Botun adi: darklord5456
- Sohbete yaz:  darklord5456 gel   /  darklord5456 dur  /  darklord5456 odun  /  darklord5456 ates
- Sadece "darklord5456" yazarsan sana gelir. Isimle yazinca, yuklu alanda neredeyse oradan duyar ve yanina isinlanir.

YENI KOMUTLAR
- ev yap          -> senin yaninda 9x9 ev yapar (kapi, pencere, cati, masa, ocak, sandik, mesale)
- oldur           -> baktigin canliyi (zombi vb.) olduruur. Once ona bak, sonra yaz.
- oyunculari oldur-> baska oyunculari avlar (seni degil). Seni vuran/olduren kisiye de kendiliginden saldirir.
- maden / kaz     -> komur, demir, altin, elmas, zumrut, lapis, redstone, kuvars kazar
- tas             -> sadece tas
- Seni bir canavar vurursa Bot kendiliginden ona saldirir.

BUYU ASALARI (7 element)
- Yaratici modda "Savas" sekmesinde: Ates, Buz, Elektrik, Simsek, Su, Toprak, Karanlik Asasi.
- Sag tik = buyu. Her buyunun bekleme suresi var, asa 250 kullanimda kirilir.
  Ates: patlayan ates topu | Buz: yavaslatir+zayiflatir | Elektrik: 5 canliya zincirleme atlar
  Simsek: baktigin yere yildirim | Su: onundekileri geriye iter | Toprak: havaya firlatir
  Karanlik: can calar, soldurur, kor eder (sen iyilesirsin)
- Tarif: sag ustte mücevher + 2 cubuk capraz (ate: blaze tozu, buz: buz, elektrik: redstone,
  simsek: kuvars, su: prizmarin kirigi, toprak: zumrut, karanlik: komur).
- Bot'a yaz:  darklord5456 buz / elektrik / su / toprak / karanlik / ates / yildirim
  Bot o asayi tutar ve yaklasan canavarlara o buyuyu atar.

28 BUYU (asa basina 4, shift + sag tik ile degistir)
 ATES:    Ates Topu, Alev Patlamasi, Ates Dalgasi, Meteor Yagmuru
 BUZ:     Buz Isini, Don Dalgasi, Kar Firtinasi, Buz Zirhi
 ELEKTRIK:Zincir Elektrik, Elektrik Soku, Ark Parlamasi, Asiri Yuk
 SIMSEK:  Simsek, Firtina, Gok Gurultusu, Simsek Atilisi
 SU:      Su Dalgasi, Sifa Pinari, Med Cezir, Su Kalkani
 TOPRAK:  Deprem, Tas Deri, Kaya Firlat, Sarsinti Dalgasi
 KARANLIK:Ruh Emme, Golge Dalgasi, Kaybol, Kara Delik
Bot, sectigin elementten rastgele bir saldiri buyusu atar.

RENK AYARI (B tusu)
- B'ye bas: Yildirim / Cimen / Hava sekmeleri. Hex yaz, kareden ve ton cubugundan sec, hazir renklere tikla.
- "Acik/Kapali" ile ozel rengi ac-kapat, "Sifirla" ile varsayilana don. Ayarlar kaydedilir.
- Yildirim varsayilan olarak acik renk. Tus ayari: Ayarlar > Kontroller > ColorVerse.

/CAST KOMUTU (Electroblob's Wizardry gibi)
- /cast <buyu>          -> buyuyu bakis yonune atar (ornek: /cast meteor, /cast black_hole, /cast "ates topu")
- /cast list            -> 38 buyunun hepsini elementlere gore listeler
- /cast <buyu> <oyuncu> -> baska oyuncu adina atar (op yetkisi ister)
- Tab ile buyu isimleri tamamlanir. Her buyunun kendi bekleme suresi var. Takma ad: /buyu

10 YENI BUYU
 FIRE_WALL  Ates Duvari   | ICE_PRISON   Buz Hapsi          | SPARK_STORM Kivilcim Firtinasi
 SKY_FURY   Gogun Ofkesi  | WHIRLPOOL    Girdap             | GEYSER      Gayzer
 ROOT_BIND  Kok Bagi      | STONE_FIST   Tas Yumruk         | CURSE       Lanet
 SHADOW_STEP Golge Adimi (ileri isinlanma)
 Asalarda shift+sag tik ile bunlar da secilir.

AKILLI BOT
- Arka arkaya gorev: "odun kes sonra ev yap sonra gel"  (sonra / ardindan / virgul)
- Adet: "20 odun kes", "10 maden kaz" (sayiya ulasinca siradaki goreve gecer)
- Koordinat: "git 100 64 200"   | Oyuncuya git: "darklord5456 Ahmet yanina gel"
- Buyuyu adiyla at: "meteor yagmuru", "kara delik", "girdap", "lanet" ... 38 buyunun hepsi
- Soru: "durum" / "nasilsin" / "ne yapiyorsun" -> ne yaptigini, canini, envanterini soyler
- Takip ederken yakininda canavar gorurse kendiliginden saldirir.
